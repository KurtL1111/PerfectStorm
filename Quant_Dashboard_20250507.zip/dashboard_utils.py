import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from dash import html
from typing import Any
from market_data_retrieval import MarketDataRetriever
from adaptive_thresholds_enhanced import EnhancedAdaptiveThresholds
from portfolio_optimization import PortfolioOptimizer
import math
import pandas as pd
import numpy as np
import os
import datetime

def get_standardized_model_filename(model_type, model_name, symbol=None, period=None, interval=None, base_path=None):
    """
    Create a standardized filename for model saving/loading that includes all relevant metadata.
    
    Parameters:
    - model_type: Type of model (e.g., 'anomaly_detection', 'pattern_recognition', 'clustering', 'regime_detection')
    - model_name: Specific name/algorithm of the model (e.g., 'vae', 'lstm', 'kmeans')
    - symbol: The ticker symbol used for training (default: None)
    - period: The time period used for training (default: None)
    - interval: The time interval used for training (default: None)
    - base_path: Base directory to save the model (default: None, will use 'models/{model_type}')
    
    Returns:
    - Full path to the model file with standardized naming
    """
    # Create current timestamp for model version
    timestamp = datetime.datetime.now().strftime("%Y%m%d")
    
    # Format optional parameters
    symbol_str = f"_{symbol}" if symbol else ""
    period_str = f"_{period}" if period else ""
    interval_str = f"_{interval}" if interval else ""
    
    # Create filename with all components
    filename = f"{model_type}_{model_name}{symbol_str}{period_str}{interval_str}_{timestamp}"
    
    # Set base path if not provided
    if base_path is None:
        base_path = os.path.join("models", model_type.replace("_", " ").title().replace(" ", "_"))
    
    # Create directory if it doesn't exist
    os.makedirs(base_path, exist_ok=True)
    
    return os.path.join(base_path, filename)

def create_market_data_info(df, symbol, market_breadth_data, sentiment_data):
    """
    Create market data information
    
    Parameters:
    - df: DataFrame with stock and indicator data
    - symbol: Stock symbol
    - market_breadth_data: Dictionary with market breadth data
    - sentiment_data: Dictionary with sentiment data
    
    Returns:
    - Market data information
    """
    # Get the latest data
    latest_data = df.iloc[-1]
    
    # Calculate price change and percentage change
    price_change = latest_data['close'] - df.iloc[-2]['close']
    price_change_pct = (price_change / df.iloc[-2]['close']) * 100
    
    # Check if market breadth data is available
    market_breadth_section = html.Div([
        html.H4("Market Breadth"),
        html.P("Market breadth data unavailable"),
    ], style={'width': '25%', 'display': 'inline-block'})
    
    if market_breadth_data is not None:
        market_breadth_section = html.Div([
            html.H4("Market Breadth"),
            html.P(f"Advancing Issues: {market_breadth_data['advancing_issues']}"),
            html.P(f"Declining Issues: {market_breadth_data['declining_issues']}"),
            html.P(f"ARMS Index: {latest_data.get('arms_index', 'N/A')}"),
        ], style={'width': '25%', 'display': 'inline-block'})
    
    # Check if sentiment data is available
    sentiment_section = html.Div([
        html.H4("Sentiment"),
        html.P("Sentiment data unavailable"),
    ], style={'width': '25%', 'display': 'inline-block'})
    
    if sentiment_data is not None:
        # Ensure sentiment values are numeric, handling potential lists
        bullish = sentiment_data.get('bullish', 0.0)
        bearish = sentiment_data.get('bearish', 0.0)
        neutral = sentiment_data.get('neutral', 0.0)

        # Handle cases where values might be lists (e.g., from API response)
        if isinstance(bullish, list):
            bullish = float(bullish[0]) if bullish and isinstance(bullish[0], (int, float)) else 0.0
        if isinstance(bearish, list):
            bearish = float(bearish[0]) if bearish and isinstance(bearish[0], (int, float)) else 0.0
        if isinstance(neutral, list):
            neutral = float(neutral[0]) if neutral and isinstance(neutral[0], (int, float)) else 0.0

        # Ensure they are floats after potential list extraction or if they were already numbers
        try:
            bullish = float(bullish)
        except (ValueError, TypeError):
            bullish = 0.0
        try:
            bearish = float(bearish)
        except (ValueError, TypeError):
            bearish = 0.0
        try:
            neutral = float(neutral)
        except (ValueError, TypeError):
            neutral = 0.0
            
        sentiment_section = html.Div([
            html.H4("Sentiment"),
            html.P(f"Bullish: {bullish:.1f}%"),
            html.P(f"Bearish: {bearish:.1f}%"),
            html.P(f"Neutral: {neutral:.1f}%"),
        ], style={'width': '25%', 'display': 'inline-block'})
    
    # Create market data info
    market_data_info = html.Div([
        html.Div([
            html.H3(f"{symbol} - {latest_data.name.strftime('%Y-%m-%d')}"),
            html.P(f"Close: ${latest_data['close']:.2f} ({price_change_pct:.2f}%)"),
        ], style={'width': '25%', 'display': 'inline-block'}),
        
        market_breadth_section,
        sentiment_section,
        
        html.Div([
            html.H4("Key Indicators"),
            html.P(f"RSI: {latest_data.get('rsi', 'N/A')}"),
            html.P(f"MACD: {latest_data.get('macd_line', 'N/A')}"),
            html.P(f"CCI: {latest_data.get('cci', 'N/A')}"),
        ], style={'width': '25%', 'display': 'inline-block'}),
    ])
    
    return market_data_info

def create_main_chart(df, symbol):
    """
    Create main chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    - symbol: Stock symbol
    
    Returns:
    - Main chart figure
    """
    # Create figure
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                        vertical_spacing=0.1, 
                        row_heights=[0.7, 0.3],
                        subplot_titles=(f"{symbol} Price", "Volume"))
    
    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=df.index,
            open=df['open'],
            high=df['high'],
            low=df['low'],
            close=df['close'],
            name="Price"
        ),
        row=1, col=1
    )
    
    # Add Bollinger Bands
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['bb_upper'],
            mode='lines',
            line=dict(width=1, color='rgba(173, 204, 255, 0.7)'),
            name="Upper BB"
        ),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['bb_middle'],
            mode='lines',
            line=dict(width=1, color='rgba(173, 204, 255, 0.7)'),
            name="Middle BB"
        ),
        row=1, col=1
    )
    
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['bb_lower'],
            mode='lines',
            line=dict(width=1, color='rgba(173, 204, 255, 0.7)'),
            name="Lower BB",
            fill='tonexty',
            fillcolor='rgba(173, 204, 255, 0.2)'
        ),
        row=1, col=1
    )
    
    # Add buy/sell signals if available
    if 'buy_signal' in df.columns and 'sell_signal' in df.columns:
        # Filter for buy signals
        buy_signals = df[df['buy_signal'] == 1]
        if not buy_signals.empty:
            fig.add_trace(
                go.Scatter(
                    x=buy_signals.index,
                    y=buy_signals['low'] * 0.99,  # Slightly below the low price
                    mode='markers',
                    marker=dict(symbol='triangle-up', size=10, color='green'),
                    name="Buy Signal"
                ),
                row=1, col=1
            )
        
        # Filter for sell signals
        sell_signals = df[df['sell_signal'] == 1]
        if not sell_signals.empty:
            fig.add_trace(
                go.Scatter(
                    x=sell_signals.index,
                    y=sell_signals['high'] * 1.01,  # Slightly above the high price
                    mode='markers',
                    marker=dict(symbol='triangle-down', size=10, color='red'),
                    name="Sell Signal"
                ),
                row=1, col=1
            )
    
    # Add volume chart
    colors = ['red' if row['open'] > row['close'] else 'green' for i, row in df.iterrows()]
    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df['volume'],
            marker_color=colors,
            name="Volume"
        ),
        row=2, col=1
    )
    
    # Update layout
    fig.update_layout(
        height=600,
        xaxis_rangeslider_visible=False,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    # Update y-axis labels
    fig.update_yaxes(title_text="Price ($)", row=1, col=1)
    fig.update_yaxes(title_text="Volume", row=2, col=1)
    
    return fig

def create_indicators_chart(df):
    """
    Create indicators chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    
    Returns:
    - Indicators chart figure
    """
    # Create figure with 2 rows for MACD and RSI
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                        vertical_spacing=0.1, 
                        row_heights=[0.5, 0.5],
                        subplot_titles=("MACD", "RSI"))
    # Add MACD traces
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['macd_line'],
            mode='lines',
            name="MACD Line"
        ),
        row=1, col=1
    )
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['macd_signal'],
            mode='lines',
            name="Signal Line"
        ),
        row=1, col=1
    )
    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df['macd_hist'],
            name="MACD Histogram",
            marker_color=['red' if val < 0 else 'green' for val in df['macd_hist']]
        ),
        row=1, col=1
    )
    # Add RSI trace
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['rsi'],
            mode='lines',
            name="RSI"
        ),
        row=2, col=1
    )
    # Get adaptive RSI thresholds using get_threshold_recommendations
    thresholds_model = EnhancedAdaptiveThresholds()
    rsi_recommendation = thresholds_model.get_threshold_recommendations(df, indicator_col='rsi')
    rsi_overbought = rsi_recommendation['upper_threshold']
    rsi_oversold = rsi_recommendation['lower_threshold']
    # Add adaptive overbought line
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=[rsi_overbought] * len(df),
            mode='lines',
            line=dict(dash='dash', color='red'),
            name=f"Overbought (Adaptive: {rsi_overbought:.2f})"
        ),
        row=2, col=1
    )
    # Add adaptive oversold line
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=[rsi_oversold] * len(df),
            mode='lines',
            line=dict(dash='dash', color='green'),
            name=f"Oversold (Adaptive: {rsi_oversold:.2f})"
        ),
        row=2, col=1
    )
    # Update layout
    fig.update_layout(
        height=400,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    # Update y-axis labels
    fig.update_yaxes(title_text="MACD", row=1, col=1)
    fig.update_yaxes(title_text="RSI", row=2, col=1)
    return fig

def create_moving_averages_chart(df):
    """
    Create moving averages chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    
    Returns:
    - Moving averages chart figure
    """
    # Create figure
    fig = go.Figure()
    
    # Add price
    fig.add_trace(
        go.Scatter(
            x=df.index,
            y=df['close'],
            mode='lines',
            name="Close Price"
        )
    )
    
    # Add moving averages
    ma_periods = [5, 9, 20, 50, 100, 200]
    colors = ['blue', 'green', 'red', 'purple', 'orange', 'brown']
    
    for i, period in enumerate(ma_periods):
        if f'ma_{period}' in df.columns:
            fig.add_trace(
                go.Scatter(
                    x=df.index,
                    y=df[f'ma_{period}'],
                    mode='lines',
                    name=f"{period}-day MA",
                    line=dict(color=colors[i % len(colors)])
                )
            )
    
    # Update layout
    fig.update_layout(
        title="Moving Averages",
        height=400,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    # Update y-axis label
    fig.update_yaxes(title_text="Price ($)")
    
    return fig

def create_volume_chart(df):
    """
    Create volume chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    
    Returns:
    - Volume chart figure
    """
    # Create figure
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                        vertical_spacing=0.1, 
                        row_heights=[0.5, 0.5],
                        subplot_titles=("Volume", "Chaikin Money Flow"))
    
    # Add volume
    colors = ['red' if row['open'] > row['close'] else 'green' for i, row in df.iterrows()]
    fig.add_trace(
        go.Bar(
            x=df.index,
            y=df['volume'],
            marker_color=colors,
            name="Volume"
        ),
        row=1, col=1
    )
    
    # Add volume moving average
    if 'volume_ma' in df.columns:
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['volume_ma'],
                mode='lines',
                name="Volume MA",
                line=dict(color='blue')
            ),
            row=1, col=1
        )
    
    # Add Chaikin Money Flow
    if 'cmf' in df.columns:
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['cmf'],
                mode='lines',
                name="CMF",
                line=dict(color='purple')
            ),
            row=2, col=1
        )
        
        # Add zero line
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=[0] * len(df),
                mode='lines',
                line=dict(dash='dash', color='black'),
                name="Zero Line"
            ),
            row=2, col=1
        )
    
    # Update layout
    fig.update_layout(
        height=400,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    # Update y-axis labels
    fig.update_yaxes(title_text="Volume", row=1, col=1)
    fig.update_yaxes(title_text="CMF", row=2, col=1)
    
    return fig

def create_oscillators_chart(df):
    """
    Create oscillators chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    
    Returns:
    - Oscillators chart figure
    """
    # Create figure
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, 
                        vertical_spacing=0.1, 
                        row_heights=[0.5, 0.5],
                        subplot_titles=("Stochastic Oscillator", "CCI"))
    
    # Add Stochastic Oscillator
    if 'stoch_k' in df.columns and 'stoch_d' in df.columns:
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['stoch_k'],
                mode='lines',
                name="%K"
            ),
            row=1, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['stoch_d'],
                mode='lines',
                name="%D"
            ),
            row=1, col=1
        )
        
        # Add overbought/oversold lines
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=[80] * len(df),
                mode='lines',
                line=dict(dash='dash', color='red'),
                name="Overbought (80)"
            ),
            row=1, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=[20] * len(df),
                mode='lines',
                line=dict(dash='dash', color='green'),
                name="Oversold (20)"
            ),
            row=1, col=1
        )
    
    # Add CCI
    if 'cci' in df.columns:
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['cci'],
                mode='lines',
                name="CCI"
            ),
            row=2, col=1
        )
        
        # Add overbought/oversold lines
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=[100] * len(df),
                mode='lines',
                line=dict(dash='dash', color='red'),
                name="Overbought (100)"
            ),
            row=2, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=[-100] * len(df),
                mode='lines',
                line=dict(dash='dash', color='green'),
                name="Oversold (-100)"
            ),
            row=2, col=1
        )
    
    # Update layout
    fig.update_layout(
        height=400,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    # Update y-axis labels
    fig.update_yaxes(title_text="Stochastic", row=1, col=1)
    fig.update_yaxes(title_text="CCI", row=2, col=1)
    
    return fig

def create_sentiment_chart(df, sentiment_data):
    """
    Create sentiment chart
    
    Parameters:
    - df: DataFrame with stock and indicator data
    - sentiment_data: Dictionary with sentiment data
    
    Returns:
    - Sentiment chart figure
    """
    # Create figure
    fig = make_subplots(rows=1, cols=1)
    
    # Check if sentiment data is available
    if sentiment_data is None:
        fig.add_annotation(
            text="Sentiment data unavailable",
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=20)
        )
        return fig
    
    # Create sentiment chart
    fig.add_trace(
        go.Bar(
            x=['Bullish', 'Bearish', 'Neutral'],
            y=[sentiment_data['bullish'], sentiment_data['bearish'], sentiment_data['neutral']],
            marker_color=['green', 'red', 'blue']
        )
    )
    
    # Add bulls vs bears ratio if available
    if 'bulls_bears_ratio' in df.columns:
        # Create a secondary y-axis for the ratio
        fig = make_subplots(rows=1, cols=1, specs=[[{"secondary_y": True}]])
        
        # Add sentiment bars
        fig.add_trace(
            go.Bar(
                x=['Bullish', 'Bearish', 'Neutral'],
                y=[sentiment_data['bullish'], sentiment_data['bearish'], sentiment_data['neutral']],
                marker_color=['green', 'red', 'blue'],
                name="Sentiment"
            ),
            secondary_y=False
        )
        
        # Add bulls vs bears ratio line
        latest_ratio = df['bulls_bears_ratio'].iloc[-1]
        fig.add_trace(
            go.Scatter(
                x=['Bullish', 'Bearish', 'Neutral'],
                y=[latest_ratio, latest_ratio, latest_ratio],
                mode='lines',
                name=f"Bulls/Bears Ratio: {latest_ratio:.2f}",
                line=dict(color='black', dash='dash')
            ),
            secondary_y=True
        )
    
    # Update layout
    fig.update_layout(
        title="AAII Investor Sentiment Survey",
        height=400,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    # Update y-axis labels
    fig.update_yaxes(title_text="Percentage (%)", secondary_y=False)
    if 'bulls_bears_ratio' in df.columns:
        fig.update_yaxes(title_text="Bulls/Bears Ratio", secondary_y=True)
    
    return fig

def create_backtesting_results(backtest_results):
    """
    Create a formatted display for backtesting results.
    
    Parameters:
    - backtest_results: Dictionary with backtesting performance metrics.
    
    Returns:
    - HTML Div displaying backtesting results.
    """
    return html.Div([
        html.H4("Performance Metrics"),
        html.P(f"Sharpe Ratio: {backtest_results.get('sharpe_ratio', 'N/A'):.2f}"),
        html.P(f"Maximum Drawdown: {backtest_results.get('max_drawdown', 'N/A'):.2%}"),
        html.P(f"Win Rate: {backtest_results.get('win_rate', 'N/A'):.2%}"),
        html.P(f"Total Return: {backtest_results.get('total_return', 'N/A'):.2%}"),
        html.P(f"Annualized Volatility: {backtest_results.get('volatility', 'N/A'):.2%}"),
        html.P(f"Profit Factor: {backtest_results.get('profit_factor', 'N/A'):.2f}")
    ])

def create_perfect_storm_analysis(df):
    """
    Create Perfect Storm analysis
    
    Parameters:
    - df: DataFrame with stock and indicator data
    
    Returns:
    - Perfect Storm analysis
    """
    # Get the latest data
    latest_data = df.iloc[-1]
    
    # Check if we have all the required indicators
    required_indicators = ['rsi', 'macd_line', 'macd_signal', 'stoch_k', 'stoch_d', 'cci', 'bb_upper', 'bb_lower']
    missing_indicators = [ind for ind in required_indicators if ind not in df.columns]
    
    if missing_indicators:
        return html.Div([
            html.P(f"Missing indicators: {', '.join(missing_indicators)}"),
            html.P("Cannot perform Perfect Storm analysis without all required indicators.")
        ])
    
    # Create analysis
    analysis = []
    
    # Check for buy signals
    buy_signals = []
    if latest_data.get('rsi', 0) < 40:
        buy_signals.append("RSI is below 40")
    if latest_data.get('macd_line', 0) > latest_data.get('macd_signal', 0):
        buy_signals.append("MACD line is above signal line")
    if latest_data.get('stoch_k', 0) < 20:
        buy_signals.append("Stochastic %K is below 20 (oversold)")
    if latest_data.get('cci', 0) < -100:
        buy_signals.append("CCI is below -100 (oversold)")
    if latest_data.get('close', 0) < latest_data.get('bb_lower', 0):
        buy_signals.append("Price is below lower Bollinger Band")
    
    # Check for sell signals
    sell_signals = []
    if latest_data.get('rsi', 0) > 65:
        sell_signals.append("RSI is above 65")
    if latest_data.get('macd_line', 0) < latest_data.get('macd_signal', 0):
        sell_signals.append("MACD line is below signal line")
    if latest_data.get('stoch_k', 0) > 80:
        sell_signals.append("Stochastic %K is above 80 (overbought)")
    if latest_data.get('cci', 0) > 100:
        sell_signals.append("CCI is above 100 (overbought)")
    if latest_data.get('close', 0) > latest_data.get('bb_upper', 0):
        sell_signals.append("Price is above upper Bollinger Band")
    
    # Add buy signals
    if buy_signals:
        analysis.append(html.Div([
            html.H4("Buy Signals", style={'color': 'green'}),
            html.Ul([html.Li(signal) for signal in buy_signals])
        ]))
    
    # Add sell signals
    if sell_signals:
        analysis.append(html.Div([
            html.H4("Sell Signals", style={'color': 'red'}),
            html.Ul([html.Li(signal) for signal in sell_signals])
        ]))
    
    # Add overall recommendation
    if len(buy_signals) > len(sell_signals) and len(buy_signals) >= 3:
        analysis.append(html.Div([
            html.H4("Overall Recommendation", style={'fontWeight': 'bold'}),
            html.P("BUY", style={'color': 'green', 'fontSize': '24px', 'fontWeight': 'bold'})
        ]))
    elif len(sell_signals) > len(buy_signals) and len(sell_signals) >= 3:
        analysis.append(html.Div([
            html.H4("Overall Recommendation", style={'fontWeight': 'bold'}),
            html.P("SELL", style={'color': 'red', 'fontSize': '24px', 'fontWeight': 'bold'})
        ]))
    else:
        analysis.append(html.Div([
            html.H4("Overall Recommendation", style={'fontWeight': 'bold'}),
            html.P("HOLD", style={'color': 'blue', 'fontSize': '24px', 'fontWeight': 'bold'})
        ]))
    
    return analysis

def create_backtesting_chart(backtester) -> go.Figure:
    # Function to create backtesting chart
    fig = go.Figure()
    if 'date' in backtester and 'performance' in backtester:
        fig.add_trace(go.Scatter(x=backtester['date'], y=backtester['performance'], mode='lines', name='Backtesting Performance'))
    return fig

def create_correlation_report_charts(correlation_report):
    """
    Create plotly figures from correlation report
    
    Parameters:
    - correlation_report: Dictionary with report components from CorrelationAnalysis.generate_correlation_report
    
    Returns:
    - Dictionary of plotly figures for correlation report visualizations
    """
    figures = {}
    
    # Check if visualizations are available in the report
    if correlation_report is None or 'visualizations' not in correlation_report:
        # Create empty placeholder figures
        empty_fig = go.Figure()
        empty_fig.update_layout(
            title="No Correlation Data Available",
            annotations=[{
                'text': 'Correlation analysis data not available',
                'xref': 'paper',
                'yref': 'paper',
                'x': 0.5,
                'y': 0.5,
                'showarrow': False,
                'font': {'size': 16}
            }]
        )
        return {
            'correlation_matrix': empty_fig,
            'redundancy_groups': empty_fig,
            'feature_importance': empty_fig
        }
    
    # Extract visualizations from the report
    visualizations = correlation_report['visualizations']
    
    # Process correlation matrix chart
    if 'correlation_matrix' in visualizations:
        figures['correlation_matrix'] = visualizations['correlation_matrix']
    else:
        figures['correlation_matrix'] = go.Figure().update_layout(title="Correlation Matrix Not Available")
    
    # Process redundancy groups chart
    if 'redundancy_groups' in visualizations:
        figures['redundancy_groups'] = visualizations['redundancy_groups']
    else:
        figures['redundancy_groups'] = go.Figure().update_layout(title="Redundancy Groups Not Available")
    
    # Process feature importance chart
    if 'feature_importance' in visualizations:
        figures['feature_importance'] = visualizations['feature_importance']
    else:
        figures['feature_importance'] = go.Figure().update_layout(title="Feature Importance Not Available")
    
    # Enhance all figures with common styling
    for name, fig in figures.items():
        fig.update_layout(
            template='plotly_white',
            margin=dict(l=50, r=50, t=80, b=50),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            font=dict(family="Arial, sans-serif", size=12),
            title=dict(
                text=name.replace('_', ' ').title(),
                font=dict(size=20)
            )
        )
    
    return figures

def create_correlation_dashboard_component(correlation_report):
    """
    Create a Dash HTML component displaying a summary of the correlation analysis
    
    Parameters:
    - correlation_report: Dictionary with report components from CorrelationAnalysis.generate_correlation_report
    
    Returns:
    - Dash HTML component with correlation summary
    """
    if correlation_report is None or not all(key in correlation_report for key in ['redundancy_groups', 'unique_indicators']):
        return html.Div([
            html.P("Correlation analysis data not available or incomplete.")
        ])
    
    # Create summary of redundancy groups
    redundancy_groups = html.Div([
        html.H4("Redundancy Groups", style={'color': '#2c3e50'}),
        html.P("These groups of indicators provide similar information and can be reduced to a single representative:"),
        html.Table(
            # Header row
            [html.Tr([html.Th("Group"), html.Th("Indicators")])] +
            # Data rows
            [html.Tr([
                html.Td(f"Group {i+1}"), 
                html.Td(", ".join(group))
            ]) for i, group in enumerate(correlation_report['redundancy_groups'])],
            style={
                'width': '100%',
                'border-collapse': 'collapse',
                'margin-bottom': '20px'
            }
        ) if correlation_report['redundancy_groups'] else html.P("No redundancy groups identified.")
    ])
    
    # Create summary of unique indicators
    unique_indicators = html.Div([
        html.H4("Unique Indicators", style={'color': '#2c3e50'}),
        html.P("These indicators provide unique information and should be prioritized:"),
        html.Ul([
            html.Li(indicator) for indicator in correlation_report['unique_indicators']
        ]) if correlation_report['unique_indicators'] else html.P("No unique indicators identified.")
    ])
    
    # Create summary of feature importance if available
    feature_importance = html.Div()
    if 'feature_importance' in correlation_report and correlation_report['feature_importance'] is not None:
        # Sort by importance
        sorted_importance = correlation_report['feature_importance'].sort_values(ascending=False)
        # Take top 10 for display
        top_indicators = sorted_importance.head(10)
        
        feature_importance = html.Div([
            html.H4("Top 10 Most Important Indicators", style={'color': '#2c3e50'}),
            html.P("These indicators have the highest predictive power:"),
            html.Table(
                # Header row
                [html.Tr([html.Th("Indicator"), html.Th("Importance")])] +
                # Data rows
                [html.Tr([
                    html.Td(indicator), 
                    html.Td(f"{importance:.4f}")
                ]) for indicator, importance in top_indicators.items()],
                style={
                    'width': '100%',
                    'border-collapse': 'collapse',
                    'margin-bottom': '20px'
                }
            )
        ])
    
    # Create recommendations
    optimal_indicators = html.Div()
    if 'optimal_indicators' in correlation_report and correlation_report['optimal_indicators']:
        optimal_indicators = html.Div([
            html.H4("Recommended Optimal Indicator Set", style={'color': '#2c3e50'}),
            html.P("For the best trading performance, consider focusing on this subset of indicators:"),
            html.Ul([
                html.Li(indicator) for indicator in correlation_report['optimal_indicators']
            ])
        ])
    
    # Multi-method analysis results (new section)
    multi_method_section = html.Div()
    if 'multi_method_results' in correlation_report and correlation_report['multi_method_results']:
        # Extract results from multiple method combinations
        multi_results = correlation_report['multi_method_results']
        
        # Create a section for consistent indicators across methods
        consistent_indicators_div = html.Div()
        if 'consistent_indicators' in correlation_report:
            consistent_indicators = correlation_report.get('consistent_indicators', [])
            consistent_indicators_div = html.Div([
                html.H4("Consistent Indicators Across Methods", style={'color': '#2c3e50'}),
                html.P("These indicators show consistent importance across different correlation and feature selection methods:"),
                html.Ul([
                    html.Li(indicator) for indicator in consistent_indicators
                ]) if consistent_indicators else html.P("No consistently important indicators identified across methods.")
            ])
        
        # Create a comparison of results across different methods if available
        method_comparison_table = html.Div()
        if len(multi_results) > 1:
            # Create a table comparing feature importance across methods
            # Show top 5 indicators from each method
            top_indicators_by_method = {}
            all_top_indicators = set()
            
            for method_name, result in multi_results.items():
                if 'feature_importance' in result:
                    # Get top 5 indicators
                    top_5 = result['feature_importance'].nlargest(5).index.tolist()
                    top_indicators_by_method[method_name] = top_5
                    all_top_indicators.update(top_5)
            
            if top_indicators_by_method:
                # Create table header with method names
                method_names = list(top_indicators_by_method.keys())
                
                method_comparison_table = html.Div([
                    html.H4("Top 5 Indicators by Method", style={'color': '#2c3e50'}),
                    html.P("Comparison of top indicators across different analysis methods:"),
                    html.Table(
                        # Header row
                        [html.Tr([html.Th("Method")] + [html.Th(f"#{i+1}") for i in range(5)])] +
                        # Data rows for each method
                        [html.Tr([
                            html.Td(method_name),
                            *[html.Td(top_indicators_by_method[method_name][i] if i < len(top_indicators_by_method[method_name]) else "-") 
                              for i in range(5)]
                        ]) for method_name in method_names],
                        style={
                            'width': '100%',
                            'border-collapse': 'collapse',
                            'margin-bottom': '20px'
                        }
                    )
                ])
        
        # Create a summary of redundancy groups that are consistent across methods
        consistent_redundancy_div = html.Div()
        if 'consistent_redundant_pairs' in correlation_report:
            consistent_pairs = correlation_report.get('consistent_redundant_pairs', [])
            consistent_redundancy_div = html.Div([
                html.H4("Consistently Redundant Indicators", style={'color': '#2c3e50'}),
                html.P("These indicator pairs show consistent redundancy across different correlation methods:"),
                html.Ul([
                    html.Li(f"{pair[0]} and {pair[1]}") for pair in consistent_pairs
                ]) if consistent_pairs else html.P("No consistently redundant indicator pairs identified across methods.")
            ])
        
        # Combine multi-method sections
        multi_method_section = html.Div([
            html.H3("Multi-Method Analysis Results", style={'textAlign': 'center', 'marginTop': '30px', 'marginBottom': '20px'}),
            html.P(f"Analysis performed using {len(multi_results)} different combinations of correlation and feature selection methods."),
            consistent_indicators_div,
            consistent_redundancy_div,
            method_comparison_table
        ], style={
            'backgroundColor': '#f0f8ff',
            'padding': '15px',
            'borderRadius': '5px',
            'border': '1px solid #b0c4de',
            'marginTop': '20px',
            'marginBottom': '20px'
        }) if multi_results else html.Div()
    
    # Combine all elements
    return html.Div([
        html.H3("Correlation Analysis Summary", style={'textAlign': 'center', 'marginBottom': '20px'}),
        redundancy_groups,
        unique_indicators,
        feature_importance,
        optimal_indicators,
        multi_method_section,  # Add the multi-method section
        html.Hr(),
        html.P("This analysis helps identify which indicators provide unique information and which are redundant, allowing for a more focused trading strategy.", style={'fontStyle': 'italic'})
    ], style={
        'backgroundColor': '#f9f9f9',
        'padding': '20px',
        'borderRadius': '5px',
        'border': '1px solid #ddd',
        'marginTop': '20px',
        'marginBottom': '20px'
    })

def create_portfolio_report_charts(portfolio_report, symbol='Portfolio'):
    """
    Create Plotly figures from portfolio report visualizations
    
    Parameters:
    - portfolio_report: Dictionary with report components from PortfolioOptimizer.generate_portfolio_report
    - symbol: Stock symbol or portfolio name
    
    Returns:
    - Dictionary of plotly figures for portfolio report visualizations
    """
    figures = {}
    
    # Check if report is available
    if portfolio_report is None or 'visualizations' not in portfolio_report:
        # Create empty placeholder figures
        empty_fig = go.Figure()
        empty_fig.update_layout(
            title="No Portfolio Report Data Available",
            annotations=[{
                'text': 'Portfolio report data not available',
                'xref': 'paper',
                'yref': 'paper',
                'x': 0.5,
                'y': 0.5,
                'showarrow': False,
                'font': {'size': 16}
            }]
        )
        return {
            'efficient_frontier': empty_fig,
            'portfolio_allocation_pie': empty_fig,
            'portfolio_allocation_bar': empty_fig,
            'risk_contribution': empty_fig,
            'portfolio_performance': empty_fig
        }
    
    # Create efficient frontier figure
    if 'efficient_frontier' in portfolio_report:
        efficient_frontier = portfolio_report['efficient_frontier']
        
        # Create figure
        fig_ef = go.Figure()
        
        # Add scatter points for efficient frontier
        # Extract the relevant columns from the DataFrame
        fig_ef.add_trace(
            go.Scatter(
                x=efficient_frontier['volatility'],
                y=efficient_frontier['return'],
                mode='markers',
                marker=dict(
                    size=8,
                    color=efficient_frontier['sharpe_ratio'],
                    colorscale='Viridis',
                    colorbar=dict(title='Sharpe Ratio'),
                    showscale=True
                ),
                text=[f"Return: {r:.2%}<br>Volatility: {v:.2%}<br>Sharpe: {s:.2f}" 
                     for r, v, s in zip(efficient_frontier['return'], 
                                        efficient_frontier['volatility'], 
                                        efficient_frontier['sharpe_ratio'])],
                hoverinfo='text',
                name='Portfolios'
            )
        )
        
        # Highlight minimum volatility and maximum Sharpe ratio portfolios
        min_vol_portfolio = efficient_frontier[efficient_frontier['portfolio_type'] == 'Minimum Volatility']
        max_sharpe_portfolio = efficient_frontier[efficient_frontier['portfolio_type'] == 'Maximum Sharpe Ratio']
        
        if not min_vol_portfolio.empty:
            fig_ef.add_trace(
                go.Scatter(
                    x=min_vol_portfolio['volatility'],
                    y=min_vol_portfolio['return'],
                    mode='markers',
                    marker=dict(
                        symbol='star',
                        size=15,
                        color='red',
                        line=dict(width=2, color='DarkSlateGrey')
                    ),
                    name='Minimum Volatility'
                )
            )
        
        if not max_sharpe_portfolio.empty:
            fig_ef.add_trace(
                go.Scatter(
                    x=max_sharpe_portfolio['volatility'],
                    y=max_sharpe_portfolio['return'],
                    mode='markers',
                    marker=dict(
                        symbol='star',
                        size=15,
                        color='green',
                        line=dict(width=2, color='DarkSlateGrey')
                    ),
                    name='Maximum Sharpe Ratio'
                )
            )
        
        # Update layout
        fig_ef.update_layout(
            title='Efficient Frontier',
            xaxis_title='Volatility (Annualized)',
            yaxis_title='Return (Annualized)',
            xaxis=dict(tickformat='.0%'),
            yaxis=dict(tickformat='.0%'),
            legend=dict(
                yanchor="top",
                y=0.99,
                xanchor="left",
                x=0.01
            ),
            template='plotly_white',
            height=600
        )
        
        figures['efficient_frontier'] = fig_ef
    
    # Extract weights from recommendations
    if 'recommendations' in portfolio_report and 'optimal_weights' in portfolio_report['recommendations']:
        weights = portfolio_report['recommendations']['optimal_weights']
        
        # Create pie chart for portfolio allocation
        fig_pie = px.pie(
            data_frame=pd.DataFrame({
                'Asset': weights.index,
                'Weight': weights.values,
                'Percentage': [round(w * 100, 2) for w in weights.values]
            }),
            values='Weight',
            names='Asset',
            title=f"{symbol} Portfolio Allocation",
            color_discrete_sequence=px.colors.qualitative.G10,
            hole=0.3,
            hover_data=['Percentage']
        )
        
        fig_pie.update_traces(
            textposition='inside', 
            textinfo='percent+label',
            hovertemplate='%{label}: %{value:.2%}'
        )
        
        figures['portfolio_allocation_pie'] = fig_pie
        
        # Create bar chart for portfolio allocation
        fig_bar = px.bar(
            x=weights.index,
            y=weights.values,
            title=f"{symbol} Portfolio Weights",
            color=weights.values,
            color_continuous_scale='Viridis',
            labels={'x': 'Asset', 'y': 'Weight'},
            text=[f"{w:.2%}" for w in weights.values]
        )
        
        fig_bar.update_traces(
            texttemplate='%{text}',
            textposition='outside',
            hovertemplate='%{x}: %{y:.2%}'
        )
        
        fig_bar.update_layout(
            height=500,
            yaxis=dict(tickformat='.0%'),
            xaxis={'categoryorder':'total descending'}
        )
        
        figures['portfolio_allocation_bar'] = fig_bar
        
        # Create risk contribution chart if returns_df is available
        if 'returns_df' in portfolio_report and portfolio_report['returns_df'] is not None:
            returns_df = portfolio_report['returns_df']
            
            # Create a PortfolioOptimizer instance to calculate risk contribution
            optimizer = PortfolioOptimizer()
            metrics = optimizer.calculate_portfolio_metrics(returns_df)
            cov_matrix = metrics['cov_matrix']
            
            # Calculate portfolio volatility
            portfolio_vol = np.sqrt(np.dot(weights, np.dot(cov_matrix, weights))) * np.sqrt(252)
            
            # Calculate risk contribution
            risk_contribution = weights * np.dot(cov_matrix, weights) * 252 / portfolio_vol
            
            # Normalize to percentage
            risk_contribution_pct = risk_contribution / risk_contribution.sum() * 100
            
            # Create bar chart for risk contribution
            fig_risk = px.bar(
                x=risk_contribution_pct.index,
                y=risk_contribution_pct.values,
                title=f"{symbol} Risk Contribution",
                color=risk_contribution_pct.values,
                color_continuous_scale='Viridis',
                labels={'x': 'Asset', 'y': 'Risk Contribution (%)'},
                text=[f"{r:.2f}%" for r in risk_contribution_pct.values]
            )
            
            fig_risk.update_traces(
                texttemplate='%{text}',
                textposition='outside',
                hovertemplate='%{x}: %{y:.2f}%'
            )
            
            fig_risk.update_layout(
                height=500,
                xaxis={'categoryorder':'total descending'}
            )
            
            figures['risk_contribution'] = fig_risk
        
        # Create performance metrics visualization
        if 'performance' in portfolio_report['recommendations']:
            performance = portfolio_report['recommendations']['performance']
            
            # Get additional risk metrics
            var = portfolio_report['recommendations'].get('var', 0)
            cvar = portfolio_report['recommendations'].get('cvar', 0)
            
            # Create gauge charts for key metrics
            fig_perf = make_subplots(
                rows=2, cols=2,
                specs=[
                    [{"type": "indicator"}, {"type": "indicator"}],
                    [{"type": "indicator"}, {"type": "indicator"}]
                ],
                subplot_titles=("Expected Return", "Volatility", "Sharpe Ratio", "VaR (95%)"),
                vertical_spacing=0.1
            )
            
            # Expected Return gauge
            fig_perf.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=performance.get('returns', 0) * 100,
                    title={'text': "Expected Return (%)"},
                    number={'suffix': "%", 'valueformat': '.2f'},
                    gauge={
                        'axis': {'range': [None, max(15, math.ceil(performance.get('returns', 0) * 100))]},
                        'bar': {'color': "green" if performance.get('returns', 0) > 0 else "red"},
                        'steps': [
                            {'range': [0, 5], 'color': "lightgray"},
                            {'range': [5, 10], 'color': "gray"},
                            {'range': [10, 15], 'color': "darkgray"}
                        ]
                    }
                ),
                row=1, col=1
            )
            
            # Volatility gauge
            fig_perf.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=performance.get('volatility', 0) * 100,
                    title={'text': "Volatility (%)"},
                    number={'suffix': "%", 'valueformat': '.2f'},
                    gauge={
                        'axis': {'range': [0, max(30, math.ceil(performance.get('volatility', 0) * 100))]},
                        'bar': {'color': "orange"},
                        'steps': [
                            {'range': [0, 10], 'color': "lightgreen"},
                            {'range': [10, 20], 'color': "yellow"},
                            {'range': [20, 30], 'color': "lightcoral"}
                        ]
                    }
                ),
                row=1, col=2
            )
            
            # Sharpe Ratio gauge
            sharpe = performance.get('sharpe_ratio', 0)
            fig_perf.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=sharpe,
                    title={'text': "Sharpe Ratio"},
                    number={'valueformat': '.2f'},
                    gauge={
                        'axis': {'range': [0, max(3, math.ceil(sharpe))]},
                        'bar': {'color': "blue"},
                        'steps': [
                            {'range': [0, 1], 'color': "lightgray"},
                            {'range': [1, 2], 'color': "lightblue"},
                            {'range': [2, 3], 'color': "royalblue"}
                        ]
                    }
                ),
                row=2, col=1
            )
            
            # VaR gauge
            fig_perf.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=var * 100 if var else 0,
                    title={'text': "Value at Risk (95%)"},
                    number={'suffix': "%", 'valueformat': '.2f'},
                    gauge={
                        'axis': {'range': [0, max(10, math.ceil(var * 100) if var else 5)]},
                        'bar': {'color': "red"},
                        'steps': [
                            {'range': [0, 3], 'color': "lightgreen"},
                            {'range': [3, 6], 'color': "yellow"},
                            {'range': [6, 10], 'color': "lightcoral"}
                        ]
                    }
                ),
                row=2, col=2
            )
            
            fig_perf.update_layout(
                title=f"{symbol} Portfolio Performance Metrics",
                height=700,
                grid={'rows': 2, 'columns': 2, 'pattern': "independent"}
            )
            
            figures['portfolio_performance'] = fig_perf
    
    # Return all figures
    return figures

def create_portfolio_report_component(portfolio_report, symbol='Portfolio'):
    """
    Create a Dash HTML component displaying a summary of the portfolio report
    
    Parameters:
    - portfolio_report: Dictionary with report components from PortfolioOptimizer.generate_portfolio_report
    - symbol: Stock symbol or portfolio name
    
    Returns:
    - Dash HTML component with portfolio report summary
    """
    if portfolio_report is None or 'recommendations' not in portfolio_report:
        return html.Div([
            html.P("Portfolio report data not available or incomplete.")
        ])
    
    # Extract recommendations
    recommendations = portfolio_report['recommendations']
    
    # Check if we need to rebalance
    rebalance_needed = recommendations.get('rebalance_needed', False)
    rebalance_style = {'color': 'red', 'fontWeight': 'bold'} if rebalance_needed else {'color': 'green'}
    
    # Get risk profile
    risk_profile = recommendations.get('risk_profile', 'moderate')
    
    # Create performance section
    performance = recommendations.get('performance', {})
    performance_section = html.Div([
        html.H4("Portfolio Performance", style={'color': '#2c3e50'}),
        html.Table(
            # Header row
            [html.Tr([html.Th("Metric"), html.Th("Value")])],
            style={
                'width': '100%',
                'border-collapse': 'collapse',
                'margin-bottom': '20px'
            }
        ) if not performance else html.Table(
            # Header row
            [html.Tr([html.Th("Metric"), html.Th("Value")])] +
            # Data rows
            [
                html.Tr([html.Td("Expected Return"), html.Td(f"{performance.get('returns', 0):.2%}")]),
                html.Tr([html.Td("Volatility"), html.Td(f"{performance.get('volatility', 0):.2%}")]),
                html.Tr([html.Td("Sharpe Ratio"), html.Td(f"{performance.get('sharpe_ratio', 0):.2f}")]),
                html.Tr([html.Td("Value at Risk (95%)"), html.Td(f"{recommendations.get('var', 0):.2%}")]),
                html.Tr([html.Td("Conditional VaR (95%)"), html.Td(f"{recommendations.get('cvar', 0):.2%}")])
            ],
            style={
                'width': '100%',
                'border-collapse': 'collapse',
                'margin-bottom': '20px'
            }
        )
    ])
    
    # Create position sizes section
    if 'risk_adjusted_position_sizes' in recommendations:
        position_sizes = recommendations['risk_adjusted_position_sizes']
        position_section = html.Div([
            html.H4("Recommended Positions (Risk-Adjusted)", style={'color': '#2c3e50'}),
            html.Table(
                # Header row
                [html.Tr([html.Th("Asset"), html.Th("Allocation"), html.Th("Position Size")])] +
                # Data rows
                [html.Tr([
                    html.Td(asset), 
                    html.Td(f"{weight:.2%}"),
                    html.Td(f"${pos_size:,.2f}")
                ]) for asset, (weight, pos_size) in zip(
                    position_sizes.index, 
                    zip(recommendations['optimal_weights'], position_sizes)
                )],
                style={
                    'width': '100%',
                    'border-collapse': 'collapse',
                    'margin-bottom': '20px'
                }
            )
        ])
    else:
        position_section = html.Div()
    
    # Create risk management section
    if 'risk_management' in recommendations:
        risk_mgmt = recommendations['risk_management']
        risk_section = html.Div([
            html.H4("Risk Management Parameters", style={'color': '#2c3e50'}),
            html.Table(
                # Header row
                [html.Tr([html.Th("Parameter"), html.Th("Value")])] +
                # Data rows
                [
                    html.Tr([html.Td("Maximum Drawdown"), html.Td(f"{risk_mgmt.get('max_drawdown', 0):.2%}")]),
                    html.Tr([html.Td("Stop Loss"), html.Td(f"{risk_mgmt.get('stop_loss_pct', 0):.2%}")]),
                    html.Tr([html.Td("Take Profit"), html.Td(f"{risk_mgmt.get('take_profit_pct', 0):.2%}")]),
                    html.Tr([html.Td("Total Capital at Risk"), html.Td(f"${risk_mgmt.get('total_capital_at_risk', 0):,.2f}")])
                ],
                style={
                    'width': '100%',
                    'border-collapse': 'collapse',
                    'margin-bottom': '20px'
                }
            )
        ])
    else:
        risk_section = html.Div()
    
    # Combine all sections
    return html.Div([
        html.H3(f"{symbol} Portfolio Optimization Report", style={'textAlign': 'center', 'marginBottom': '20px'}),
        html.P(f"Risk Profile: {risk_profile.capitalize()}", style={'fontWeight': 'bold'}),
        html.P(f"Rebalancing: {'Needed' if rebalance_needed else 'Not Needed'}", style=rebalance_style),
        html.Hr(),
        performance_section,
        position_section,
        risk_section,
        html.Hr(),
        html.P("This portfolio optimization is based on historical returns and volatility. Future performance may vary.", 
              style={'fontStyle': 'italic', 'marginTop': '20px'})
    ], style={
        'backgroundColor': '#f9f9f9',
        'padding': '20px',
        'borderRadius': '5px',
        'border': '1px solid #ddd',
        'marginTop': '20px',
        'marginBottom': '20px'
    })