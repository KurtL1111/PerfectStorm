"""
Main application for Perfect Storm Dashboard

This dashboard implements the "Perfect Storm" investment strategy
developed by John R. Connelley in his book "Tech Smart".
"""

import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from market_data_retrieval import MarketDataRetriever
from technical_indicators import TechnicalIndicators
from backtesting_engine_enhanced import BacktestingEngine
from ml_pattern_recognition_enhanced import MarketPatternRecognition
from ml_clustering_enhanced_completed import PerfectStormClustering
from ml_anomaly_detection_enhanced import MarketAnomalyDetection
from adaptive_thresholds_enhanced import EnhancedAdaptiveThresholds
from market_regime_detection_completed import MarketRegimeDetection
from correlation_analysis import CorrelationAnalysis
import traceback
import logging
import os
# from dashboard_utils import (
#     create_market_data_info,
#     create_main_chart,
#     create_indicators_chart,
#     create_moving_averages_chart,
#     create_volume_chart,
#     create_oscillators_chart,
#     create_sentiment_chart,
#     create_backtesting_results,
#     create_perfect_storm_analysis,
#     create_backtesting_chart
# )
from callbacks import register_callbacks

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

# Initialize the app
app = dash.Dash(__name__, title="Perfect Storm Dashboard")
server = app.server

# Define the layout
app.layout = dbc.Container([
    html.H1("Perfect Storm Investment Strategy Dashboard", style={'textAlign': 'center'}),
    html.P("Based on John R. Connelley's strategy from 'Tech Smart'", style={'textAlign': 'center'}),
    
    dbc.Row([
        dbc.Col([
            html.Label("Stock Symbol:"),
            dcc.Input(id='symbol-input', type='text', value='AAPL'),
        ], width=3),
        
        dbc.Col([
            html.Label("Time Period:"),
            dcc.Dropdown(
                id='period-dropdown',
                options=[
                    {'label': '1 Month', 'value': '1mo'},
                    {'label': '3 Months', 'value': '3mo'},
                    {'label': '6 Months', 'value': '6mo'},
                    {'label': '1 Year', 'value': '1y'},
                    {'label': '2 Years', 'value': '2y'},
                    {'label': '5 Years', 'value': '5y'},
                ],
                value='1y'
            ),
        ], width=3),
        
        dbc.Col([
            html.Label("Interval:"),
            dcc.Dropdown(
                id='interval-dropdown',
                options=[
                    {'label': '1 Day', 'value': '1d'},
                    {'label': '1 Hour', 'value': '1h'},
                    {'label': '30 Minutes', 'value': '30m'},
                    {'label': '15 Minutes', 'value': '15m'},
                    {'label': '5 Minutes', 'value': '5m'},
                ],
                value='1d'
            ),
        ], width=3),
        
        dbc.Col([
            html.Button('Update Dashboard', id='update-button', n_clicks=0),
        ], width=3),
    ]),

    # --- Manual Market Breadth Input Section ---
    dbc.Row([
        dbc.Col([
            html.H4("Manual Market Breadth Input", style={'marginTop': '20px'}),
            dbc.Row([
                dbc.Col(dcc.Input(id='adv-issues-input', type='number', placeholder='Advancing Issues'), width=3),
                dbc.Col(dcc.Input(id='dec-issues-input', type='number', placeholder='Declining Issues'), width=3),
                dbc.Col(dcc.Input(id='adv-volume-input', type='number', placeholder='Advancing Volume'), width=3),
                dbc.Col(dcc.Input(id='dec-volume-input', type='number', placeholder='Declining Volume'), width=3),
            ]),
            dbc.Button("Save Market Breadth Data", id="save-breadth-button", n_clicks=0, className="mt-2"),
            html.Div(id='save-breadth-output', className="mt-2") # To display confirmation/error messages
        ], width=12)
    ], className="mt-3"),
    # --- End Manual Input Section ---
    
    # --- Portfolio Optimization Section ---
    dbc.Row([
        dbc.Col([
            html.H4("Portfolio Optimization", style={'marginTop': '20px'}),
            html.P("Create an optimized portfolio based on historical returns."),
            dbc.Row([
                dbc.Col([
                    html.Label("Stock Symbols (comma-separated):"),
                    dcc.Input(id='portfolio-symbols-input', type='text', 
                              value='AAPL,MSFT,GOOGL,AMZN',
                              placeholder='Enter symbols (e.g., AAPL,MSFT,GOOGL)'),
                ], width=6),
                dbc.Col([
                    html.Label("Look-back Period:"),
                    dcc.Dropdown(
                        id='portfolio-period-dropdown',
                        options=[
                            {'label': '6 Months', 'value': '6mo'},
                            {'label': '1 Year', 'value': '1y'},
                            {'label': '2 Years', 'value': '2y'},
                            {'label': '5 Years', 'value': '5y'},
                        ],
                        value='1y'
                    ),
                ], width=6),
            ]),
            dbc.Row([
                dbc.Col([
                    html.Label("Total Capital ($):"),
                    dcc.Input(id='portfolio-capital-input', type='number', value=100000, min=1000),
                ], width=4),
                dbc.Col([
                    html.Label("Risk Profile:"),
                    dcc.Dropdown(
                        id='portfolio-risk-profile-dropdown',
                        options=[
                            {'label': 'Conservative', 'value': 'conservative'},
                            {'label': 'Moderate', 'value': 'moderate'},
                            {'label': 'Aggressive', 'value': 'aggressive'},
                        ],
                        value='moderate'
                    ),
                ], width=4),
                dbc.Col([
                    dbc.Button("Generate Portfolio Report", id="generate-portfolio-button", 
                               color="primary", className="mt-4", n_clicks=0),
                ], width=4),
            ]),
            html.Div(id='portfolio-report-status', className="mt-2"),
        ], width=12)
    ], className="mt-3"),
    # --- End Portfolio Optimization Section ---

    html.Div(id='portfolio-report-container', children=[
        html.Div([
            html.H3("Portfolio Optimization Report"),
            html.Div(id='portfolio-report-summary'),
        ]),
        html.Div([
            html.Div([
                html.H3("Efficient Frontier"),
                dcc.Graph(id='portfolio-efficient-frontier', style={'height': '600px'}),
            ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
        ]),
        html.Div([
            html.Div([
                html.H3("Portfolio Allocation"),
                dcc.Graph(id='portfolio-allocation-pie', style={'height': '500px'}),
            ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
            html.Div([
                html.H3("Portfolio Weights"),
                dcc.Graph(id='portfolio-allocation-bar', style={'height': '500px'}),
            ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
        ]),
        html.Div([
            html.Div([
                html.H3("Risk Contribution"),
                dcc.Graph(id='portfolio-risk-contribution', style={'height': '500px'}),
            ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
            html.Div([
                html.H3("Performance Metrics"),
                dcc.Graph(id='portfolio-performance-metrics', style={'height': '700px'}),
            ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
        ]),
    ], style={'display': 'none'}),  # Initially hidden until portfolio is generated

    dbc.Row([
        dbc.Col(dcc.Loading(
            id="loading-1",
            type="circle",
            children=[
                html.Div(id='market-data-info', style={'padding': '10px', 'backgroundColor': '#f9f9f9', 'border': '1px solid #ddd', 'borderRadius': '5px', 'margin': '10px 0'}),
                dcc.Graph(id='main-chart', style={'height': '600px'}),
                html.Div([
                    html.Div([
                        html.H3("Technical Indicators"),
                        dcc.Graph(id='indicators-chart', style={'height': '400px'}),
                    ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Moving Averages"),
                        dcc.Graph(id='moving-averages-chart', style={'height': '400px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                    html.Div([
                        html.H3("Volume Analysis"),
                        dcc.Graph(id='volume-chart', style={'height': '400px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Oscillators"),
                        dcc.Graph(id='oscillators-chart', style={'height': '400px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                    html.Div([
                        html.H3("Market Sentiment"),
                        dcc.Graph(id='sentiment-chart', style={'height': '400px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.H3("Perfect Storm Analysis"),
                    html.Div(id='perfect-storm-analysis', style={'padding': '10px', 'backgroundColor': '#f9f9f9', 'border': '1px solid #ddd', 'borderRadius': '5px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Pattern Prediction"),
                        dcc.Graph(id='prediction-patterns-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("ROC Curve"),
                        dcc.Graph(id='roc-curve-chart', style={'height': '600px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Precision Recall"),
                        dcc.Graph(id='prec-recall-chart', style={'height': '600px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Confusion Matrix"),
                        dcc.Graph(id='confusion-matrix-chart', style={'height': '600px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("cluster_scatter"),
                        dcc.Graph(id='clusters-scatter-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("cluster_tsne"),
                        dcc.Graph(id='clusters-tsne-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("cluster_umap"),
                        dcc.Graph(id='clusters-umap-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Clusters Over Time"),
                        dcc.Graph(id='clusters-over-time-chart', style={'height': '1000px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Cluster Anomaly Score"),
                        dcc.Graph(id='cluster-anomalies-chart', style={'height': '1000px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Anomaly Scores Chart"),
                        dcc.Graph(id='anomaly-scores-chart', style={'height': '500px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Price Anomalies Chart"),
                        dcc.Graph(id='price-anomalies-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("Market Regime Chart"),
                        dcc.Graph(id='market-regime-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("transition_matrix"),
                        dcc.Graph(id='regime-transition-matrix', style={'height': '700px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("regime_statistics"),
                        dcc.Graph(id='regime-stats-chart', style={'height': '800px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.Div([
                        html.H3("returns_distribution"),
                        dcc.Graph(id='returns-distribution-chart', style={'height': '1600px'}),
                    ], style={'width': '50%', 'display': 'inline-block', 'padding': '10px'}),
                ]),
                html.Div([
                    html.H3("Backtesting Results"),
                    dcc.Graph(id='backtesting-results-chart', style={'height': '700px'}),
                ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
                html.Div([
                    html.H3("Correlation Matrix"),
                    dcc.Graph(id='correlation-matrix-chart', style={'height': '800px'}),
                ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
                html.Div([
                    html.H3("Redundancy Groups"),
                    dcc.Graph(id='redundancy-groups-chart', style={'height': '650px'}),
                ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
                html.Div([
                    html.H3("Feature Importance"),
                    dcc.Graph(id='feature-importance-chart', style={'height': '650px'}),
                ], style={'width': '100%', 'display': 'inline-block', 'padding': '10px'}),
            ]
        ), width=12),
    ]),
    
    html.Div(id='alerts-div', style={'padding': '10px', 'backgroundColor': '#ffe6e6', 'border': '1px solid red', 'margin': '10px'}),
    dcc.Interval(id='real-time-alerts', interval=60000, n_intervals=0),
    
    html.Div([
        html.Hr(),
        html.P("Data sources: Yahoo Finance, MarketWatch, AAII Investor Sentiment Survey", style={'textAlign': 'center'}),
        html.P("© 2025 Perfect Storm Dashboard", style={'textAlign': 'center'}),
    ]),
], fluid=True, className="dbc")

# Register callbacks
register_callbacks(app)


if __name__ == '__main__':
    app.run(debug=True, host='localhost')
