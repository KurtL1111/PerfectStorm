import pandas as pd
import numpy as np

class ConvictionScoreCalculator:
    def __init__(self, weights=None):
        """
        Initializes the ConvictionScoreCalculator.

        Args:
            weights (dict, optional): A dictionary to override default weights.
                                      Example: {
                                          'adaptive_signals': 0.4,
                                          'market_regime': 0.3,
                                          'ml_pattern': 0.15,
                                          'anomaly_score': 0.15
                                      }
        """
        default_weights = {
            'adaptive_signals': 0.4,
            'market_regime': 0.3,
            'ml_pattern': 0.15,     # Placeholder for ML pattern recognition confidence
            'anomaly_score': 0.15,  # Placeholder for market anomaly scores
            # Future potential weights:
            # 'sentiment': 0.1,
            # 'volume_confirmation': 0.1,
            # 'correlation_signal_strength': 0.1
        }
        self.weights = {**default_weights, **(weights or {})}
        print(f"ConvictionScoreCalculator initialized with weights: {self.weights}")

    def _normalize_adaptive_signals(self, df):
        """
        Normalizes the contribution of adaptive indicator signals to a -1 to +1 score.
        Assumes df contains 'individual_buy_signals_adaptive' and 'individual_sell_signals_adaptive'.
        """
        if 'individual_buy_signals_adaptive' not in df.columns or \
           'individual_sell_signals_adaptive' not in df.columns:
            print("Warning: Adaptive signal columns not found. Returning neutral signal score (0).")
            return pd.Series(0, index=df.index)

        buy_signals = df['individual_buy_signals_adaptive']
        sell_signals = df['individual_sell_signals_adaptive']
        
        # Total potential signals (max of buy or sell at any point, or a predefined max if available)
        # For simplicity, let's assume the sum of buy and sell could be a proxy for total activity if non-zero
        total_signals = buy_signals + sell_signals
        # Avoid division by zero if no signals are present
        score = np.where(total_signals > 0, (buy_signals - sell_signals) / total_signals, 0)
        return pd.Series(score, index=df.index)

    def _normalize_market_regime(self, df):
        """
        Normalizes market regime to a -1 to +1 score.
        Assumes df contains 'market_regime'.
        """
        if 'market_regime' not in df.columns:
            print("Warning: 'market_regime' column not found. Returning neutral regime score (0).")
            return pd.Series(0, index=df.index)

        regime_scores = {
            'trending_up': 0.75,
            'strong_uptrend': 0.9, # Example of more granular regime
            'uptrend': 0.7,
            'trending_down': -0.75,
            'strong_downtrend': -0.9,
            'downtrend': -0.7,
            'ranging': 0.0,
            'sideways': 0.0,
            'volatile': -0.25, # Penalize pure volatility unless other signals confirm direction
            'low_volatility': 0.1, # Slight positive for low vol if other things are neutral
            'unknown': 0.0
        }
        # Ensure all regimes in the data have a score, default to 0 for unknown/new ones
        return df['market_regime'].apply(lambda x: regime_scores.get(x, 0.0))

    def _normalize_ml_pattern(self, df):
        """
        Normalizes ML pattern confidence to a -1 to +1 score.
        Assumes df might contain 'ml_pattern_confidence' (bullish 0 to 1, bearish -1 to 0).
        If not present, returns a neutral score (0).
        """
        if 'ml_pattern_confidence' not in df.columns:
            # print("Info: 'ml_pattern_confidence' column not found. Returning neutral pattern score (0).")
            return pd.Series(0, index=df.index)
        # Assuming the column is already scaled between -1 and 1.
        # If it's 0-1 for bullish and needs conversion for bearish, that logic would be here.
        return df['ml_pattern_confidence'].fillna(0)

    def _normalize_anomaly_score(self, df):
        """
        Normalizes anomaly scores to a -1 to +1 score.
        Assumes df might contain 'anomaly_score' (positive for bullish, negative for bearish).
        If not present, returns a neutral score (0).
        This might need scaling based on typical range of anomaly_score if it's not already -1 to 1.
        """
        if 'anomaly_score' not in df.columns:
            # print("Info: 'anomaly_score' column not found. Returning neutral anomaly score (0).")
            return pd.Series(0, index=df.index)
        
        # Example: If anomaly_score is unbounded, we might cap/scale it.
        # For now, assume it's reasonably scaled or we use it as is and rely on weights.
        # To truly normalize to -1 to 1, we'd need to know its typical range or use a sigmoid/tanh.
        # Simple clipping for now as a placeholder for more robust scaling:
        return df['anomaly_score'].clip(-1, 1).fillna(0)

    def calculate_score(self, df_features):
        """
        Calculates the conviction score based on various features in the input DataFrame.

        Args:
            df_features (pd.DataFrame): DataFrame containing all necessary input features like
                                        adaptive signals, market regime, ML patterns, anomalies.

        Returns:
            pd.DataFrame: The input DataFrame with an added 'conviction_score' column.
        """
        if not isinstance(df_features, pd.DataFrame):
            raise ValueError("Input df_features must be a pandas DataFrame.")

        df_out = df_features.copy()

        # 1. Adaptive Signals Score
        adaptive_signal_score = self._normalize_adaptive_signals(df_out)
        
        # 2. Market Regime Score
        market_regime_score = self._normalize_market_regime(df_out)
        
        # 3. ML Pattern Confidence Score
        ml_pattern_score = self._normalize_ml_pattern(df_out)
        
        # 4. Anomaly Score
        anomaly_contrib_score = self._normalize_anomaly_score(df_out)

        # Calculate weighted conviction score
        df_out['conviction_score'] = (
            self.weights['adaptive_signals'] * adaptive_signal_score +
            self.weights['market_regime'] * market_regime_score +
            self.weights['ml_pattern'] * ml_pattern_score +
            self.weights['anomaly_score'] * anomaly_contrib_score
        )
        
        # Ensure the final score is clipped between -1 and 1
        df_out['conviction_score'] = df_out['conviction_score'].clip(-1, 1)

        print("Conviction score calculated and added to DataFrame.")
        # print(df_out[['conviction_score', 'market_regime']].tail())
        return df_out

# Example Usage (for testing purposes):
if __name__ == '__main__':
    # Create a dummy DataFrame similar to what df_backtest might look like
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    data = {
        'close': np.random.rand(100) * 100 + 100,
        'individual_buy_signals_adaptive': np.random.randint(0, 5, 100),
        'individual_sell_signals_adaptive': np.random.randint(0, 5, 100),
        'market_regime': np.random.choice(['trending_up', 'trending_down', 'ranging', 'volatile', 'unknown'], 100),
        'ml_pattern_confidence': np.random.uniform(-1, 1, 100), # Already -1 to 1
        'anomaly_score': np.random.uniform(-2, 2, 100) # Example: needs clipping/scaling
    }
    dummy_df = pd.DataFrame(data, index=dates)

    # Initialize calculator
    calculator = ConvictionScoreCalculator()

    # Calculate conviction score
    df_with_conviction = calculator.calculate_score(dummy_df)

    print("\nDataFrame with Conviction Score (last 5 rows):")
    print(df_with_conviction[['close', 'market_regime', 'individual_buy_signals_adaptive', 'individual_sell_signals_adaptive', 'ml_pattern_confidence', 'anomaly_score', 'conviction_score']].tail())

    print("\nConviction Score statistics:")
    print(df_with_conviction['conviction_score'].describe())

    # Test with missing columns
    print("\nTesting with missing ML pattern and anomaly columns:")
    dummy_df_missing = dummy_df.drop(columns=['ml_pattern_confidence', 'anomaly_score'])
    df_missing_conviction = calculator.calculate_score(dummy_df_missing)
    print(df_missing_conviction[['conviction_score']].tail())
    print(df_missing_conviction['conviction_score'].describe())