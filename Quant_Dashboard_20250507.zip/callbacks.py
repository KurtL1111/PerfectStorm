from dash import Output, Input, State, html, ctx, dcc
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import logging
import numpy as np
import traceback
import pandas as pd
import random
from datetime import datetime
from dash.exceptions import PreventUpdate
from dashboard_utils import (
    create_market_data_info,
    create_main_chart,
    create_indicators_chart,
    create_moving_averages_chart,
    create_volume_chart,
    create_oscillators_chart,
    create_sentiment_chart,
    create_backtesting_results,
    create_perfect_storm_analysis,
    create_backtesting_chart,
    create_correlation_report_charts,
    create_correlation_dashboard_component,
    create_portfolio_report_charts,
    create_portfolio_report_component
)
from market_data_retrieval import MarketDataRetriever
from technical_indicators import TechnicalIndicators
from backtesting_engine_enhanced import BacktestingEngine
from ml_pattern_recognition_enhanced import MarketPatternRecognition
from ml_clustering_enhanced_completed import PerfectStormClustering
from ml_anomaly_detection_enhanced import MarketAnomalyDetection
from adaptive_thresholds_enhanced import EnhancedAdaptiveThresholds
from market_regime_detection_completed import MarketRegimeDetection
from correlation_analysis import CorrelationAnalysis
from portfolio_optimization import PortfolioOptimizer

def register_callbacks(app):
    @app.callback(
        Output('save-breadth-output', 'children'),
        Input('save-breadth-button', 'n_clicks'),
        State('adv-issues-input', 'value'),
        State('dec-issues-input', 'value'),
        State('adv-volume-input', 'value'),
        State('dec-volume-input', 'value'),
        prevent_initial_call=True
    )
    def save_manual_breadth_data(n_clicks, adv_issues, dec_issues, adv_vol, dec_vol):
        if n_clicks == 0:
            raise PreventUpdate

        if adv_issues is None or dec_issues is None or adv_vol is None or dec_vol is None:
            return html.Div("Error: All market breadth fields must be filled.", style={'color': 'red'})
            
        try:
            adv_issues = float(adv_issues)
            dec_issues = float(dec_issues)
            adv_vol = float(adv_vol)
            dec_vol = float(dec_vol)
            
            if adv_issues < 0 or dec_issues < 0 or adv_vol < 0 or dec_vol < 0:
                 return html.Div("Error: Market breadth values cannot be negative.", style={'color': 'red'})
            if dec_issues == 0 or dec_vol == 0:
                 print("Warning: Declining issues or volume is zero, potential division by zero in ARMS index.")

        except ValueError:
            return html.Div("Error: Please enter valid numbers for all fields.", style={'color': 'red'})

        file_path = "market_breadth_manual.csv"
        today_date = datetime.now().strftime('%Y-%m-%d')
        new_data = pd.DataFrame([{
            'date': today_date,
            'advancing_issues': adv_issues,
            'declining_issues': dec_issues,
            'advancing_volume': adv_vol,
            'declining_volume': dec_vol
        }])

        try:
            if os.path.exists(file_path):
                existing_df = pd.read_csv(file_path, parse_dates=['date'])
                combined_df = pd.concat([existing_df, new_data], ignore_index=True)
                combined_df['date'] = pd.to_datetime(combined_df['date']).dt.date 
                combined_df = combined_df.drop_duplicates(subset=['date'], keep='last') 
                combined_df.to_csv(file_path, index=False, date_format='%Y-%m-%d')
                message = f"Market breadth data for {today_date} updated successfully."
            else:
                new_data.to_csv(file_path, index=False, date_format='%Y-%m-%d')
                message = f"Market breadth data file created and data for {today_date} saved successfully."
                
            return html.Div(message, style={'color': 'green'})

        except Exception as e:
            print(f"Error saving market breadth data: {e}")
            return html.Div(f"Error saving data: {str(e)}", style={'color': 'red'})

    @app.callback(
        [Output('market-data-info', 'children'),
         Output('main-chart', 'figure'),
         Output('indicators-chart', 'figure'),
         Output('moving-averages-chart', 'figure'),
         Output('volume-chart', 'figure'),
         Output('oscillators-chart', 'figure'),
         Output('sentiment-chart', 'figure'),
         Output('prediction-patterns-chart', 'figure'),
         Output('roc-curve-chart', 'figure'),
         Output('prec-recall-chart', 'figure'),
         Output('confusion-matrix-chart', 'figure'),
         Output('clusters-scatter-chart', 'figure'),
         Output('clusters-tsne-chart', 'figure'),
         Output('clusters-umap-chart', 'figure'),
         Output('clusters-over-time-chart', 'figure'),
         Output('cluster-anomalies-chart', 'figure'),
         Output('anomaly-scores-chart', 'figure'),
         Output('price-anomalies-chart', 'figure'),
         Output('market-regime-chart', 'figure'),
         Output('regime-transition-matrix', 'figure'),
         Output('regime-stats-chart', 'figure'),
         Output('returns-distribution-chart', 'figure'),
         Output('backtesting-results-chart', 'figure'),
         Output('correlation-matrix-chart', 'figure'),
         Output('redundancy-groups-chart', 'figure'),
         Output('feature-importance-chart', 'figure'),
         Output('perfect-storm-analysis', 'children')],
        [Input('update-button', 'n_clicks')],
        [State('symbol-input', 'value'),
         State('period-dropdown', 'value'),
         State('interval-dropdown', 'value')]
    )
    def update_dashboard(n_clicks, symbol, period, interval):
        triggered_id = ctx.triggered_id
        if n_clicks is None and triggered_id is None:
             raise PreventUpdate

        api_key = os.getenv("ALPHAVANTAGE_API_KEY", "25WNVRI1YIXCDIH1")
        data_retriever = MarketDataRetriever(api_key=api_key)

        stock_data = data_retriever.get_stock_history(symbol, interval=interval, period=period)

        if stock_data is None or stock_data.empty:
            empty_fig = go.Figure()
            empty_fig.update_layout(title="No Data Available")
            error_message = html.Div([
                html.H3("Data Retrieval Error"),
                html.P(f"Failed to retrieve stock data for {symbol}. Please check the symbol and try again."),
            ])
            return (error_message, empty_fig, empty_fig, empty_fig, empty_fig,
                    empty_fig, empty_fig, empty_fig, empty_fig, empty_fig,
                    empty_fig, empty_fig, empty_fig, empty_fig, empty_fig,
                    empty_fig, empty_fig, empty_fig, empty_fig, empty_fig,
                    empty_fig, empty_fig, empty_fig, empty_fig, empty_fig,
                    empty_fig, empty_fig, "Error retrieving data")
        
        # Get market breadth data
        market_breadth_data = data_retriever.get_market_breadth_data()
        
        # Get sentiment data
        sentiment_data = data_retriever.get_sentiment_data()

        # Calculate technical indicators
        df = TechnicalIndicators.calculate_all_indicators(stock_data, market_breadth_data, sentiment_data)

        # Create market data info
        market_data_info = create_market_data_info(df, symbol, market_breadth_data, sentiment_data)
        
        # Create main chart
        main_chart = create_main_chart(df, symbol)

        # Create indicators chart
        indicators_chart = create_indicators_chart(df)
        
        # Create moving averages chart
        moving_averages_chart = create_moving_averages_chart(df)
        
        # Create volume chart
        volume_chart = create_volume_chart(df)
        
        # Create oscillators chart
        oscillators_chart = create_oscillators_chart(df)
        
        # Create sentiment chart
        sentiment_chart = create_sentiment_chart(df, sentiment_data)

        #Double-Check the feature columns
        feature_cols = ['open', 'high', 'low', 'close', 'volume', 'rsi', 'stoch_k', 'stoch_d', 
                'cci', 'bb_upper', 'bb_middle', 'bb_lower', 'adx', 'mfi', 'cmf']

        # Fill NaNs with appropriate values instead of dropping
        df = df.fillna(df.mean(numeric_only=True))  # Fill numeric columns with mean values

        # Identify columns with remaining NaN values
        nan_columns = df.columns[df.isna().any()].tolist()

        # For each column with NaNs, fill with column mean or 0
        for col in nan_columns:
            if df[col].dtype.kind in 'ifc':  # If numeric column
                df[col] = df[col].fillna(df[col].mean() if not df[col].isna().all() else 0)
            else:  # If non-numeric column
                df[col] = df[col].fillna(df[col].mode()[0] if not df[col].isna().all() else "unknown")

        # ML Analysis
        pattern_model = MarketPatternRecognition()
        # Create training data and train the model
        try:
            # Create target variable for training
            df['target'] = df['close'].pct_change().shift(-1)
            df['target'] = (df['target'] > 0).astype(int)  # 1 if price goes up, 0 if down
            # Create a copy for ML processing
            df_ml = df.copy()
            # Fill NaN values in feature columns only
            for col in feature_cols:
                if col in df_ml.columns:
                    df_ml[col] = df_ml[col].fillna(method='ffill').fillna(method='bfill')
            ml_pattern_report = pattern_model.generate_pattern_report(df_ml, feature_cols, 'target', symbol=symbol, period=period, interval=interval)
        except Exception as e:
            print("ML model error:", e)
            traceback.print_exc()
            # Create empty figures for ML pattern report
            ml_pattern_report = {
                'visualizations': {
                    'predictions': go.Figure().update_layout(title="Pattern Recognition Failed"),
                    'roc_curve': go.Figure().update_layout(title="ROC Curve Failed"),
                    'precision_recall_curve': go.Figure().update_layout(title="Precision-Recall Curve Failed"),
                    'confusion_matrix': go.Figure().update_layout(title="Confusion Matrix Failed")
                }
            }
        
        clustering_model = PerfectStormClustering()
        # Create training data and train the model
        try:
            # Create a copy for clustering
            df_cluster = df.copy()
            # Fill NaN values in feature columns
            for col in feature_cols:
                if col in df_cluster.columns:
                    df_cluster[col] = df_cluster[col].fillna(method='ffill').fillna(method='bfill')
            ml_clusters_report = clustering_model.generate_clustering_report(df_cluster, feature_cols, symbol=symbol, period=period, interval=interval)
        except Exception as e:
            print("Clustering error:", e)
            traceback.print_exc()
            # Create empty figures for clustering report
            ml_clusters_report = {
                'visualizations': {
                    'cluster_scatter': go.Figure().update_layout(title="Cluster Scatter Failed"),
                    'cluster_tsne': go.Figure().update_layout(title="t-SNE Visualization Failed"),
                    'cluster_umap': go.Figure().update_layout(title="UMAP Visualization Failed"),
                    'clusters_time_series': go.Figure().update_layout(title="Clusters Over Time Failed"),
                    'anomaly_scores': go.Figure().update_layout(title="Anomaly Scores Failed")
                }
            }
        
        anomaly_model = MarketAnomalyDetection()
        # Create training data and train the model
        try:
            # Create a copy for clustering
            df_anomoly = df.copy()
            # Fill NaN values in feature columns
            for col in feature_cols:
                if col in df_anomoly.columns:
                    df_anomoly[col] = df_anomoly[col].fillna(method='ffill').fillna(method='bfill')
            anomaly_model.train_model(df_anomoly, feature_cols)  # Train the anomaly detection model
            ml_anomaly_report = anomaly_model.generate_anomaly_report(df_anomoly, feature_cols, symbol=symbol, period=period, interval=interval)
        except Exception as e:
            print("Anomaly model error:", e)
            traceback.print_exc()
            # Fallback to placeholder if training fails
            df['anomalies'] = 0
            anomalies = df[['anomalies']]
            # Create empty figures for anomaly report
            ml_anomaly_report = {
                'visualizations': {
                    'anomaly_scores': go.Figure().update_layout(title="Anomaly Scores Failed"),
                    'price_anomalies': go.Figure().update_layout(title="Price Anomalies Failed")
                }
            }

        # Adaptive thresholds integration
        thresholds_model = EnhancedAdaptiveThresholds()
        df_thresholds = df.copy()
        dynamic_thresholds = thresholds_model.get_threshold_recommendations(df_thresholds, indicator_col='rsi')

        # Initialize the regime detection model
        regime_model = MarketRegimeDetection()

        # Generate regime report
        try:
            # Create a copy of the dataframe for regime detection
            df_regime = df.copy()
            
            # Fill NaN values to ensure clean data
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df_regime.columns:
                    df_regime[col] = df_regime[col].fillna(method='ffill').fillna(method='bfill')
            
            # Generate comprehensive regime report
            regime_report = regime_model.generate_regime_report(df=df_regime, symbol=symbol, period=period)
            
            # Extract current regime information for dashboard
            current_regime = regime_report['current_regime']
            regime_name = current_regime['regime_name']
            
            # Get strategy parameters for current regime
            strategy_params = current_regime['strategy_parameters']
            
            # Get signal interpretations for current regime
            signal_interpretations = current_regime['signal_interpretations']
            
            # Add regime information to dataframe for visualization
            df['regime'] = regime_report['df_regimes']['regime']
            df['regime_name'] = regime_report['df_regimes']['regime_name']
            
        except Exception as e:
            print("Market regime detection error:", e)
            traceback.print_exc()
            # Fallback to default regime
            regime_name = "unknown"
            strategy_params = {}
            signal_interpretations = {}
            # Create empty figures for regime report
            regime_report = {
                'visualizations': {
                    'regimes': go.Figure().update_layout(title="Market Regimes Failed"),
                    'transition_matrix': go.Figure().update_layout(title="Transition Matrix Failed"),
                    'regime_statistics': go.Figure().update_layout(title="Regime Statistics Failed"),
                    'returns_distribution': go.Figure().update_layout(title="Returns Distribution Failed")
                }
            }

        # --- New Block: Set Color Scheme, Create Parameters Table, Interpret RSI ---
        # Set color scheme based on current regime
        if 'trending_up' in regime_name.lower():
            color_scheme = 'green'
        elif 'trending_down' in regime_name.lower():
            color_scheme = 'red'
        elif 'ranging' in regime_name.lower():
            color_scheme = 'blue'
        elif 'volatile' in regime_name.lower():
            color_scheme = 'orange'
        else:
            color_scheme = 'gray'

        # Create a table of strategy parameters for the current regime
        params_table = html.Table([
            html.Tr([html.Th("Parameter"), html.Th("Value")]),
            *[html.Tr([html.Td(k), html.Td(f"{v:.2f}" if isinstance(v, float) else v)])
            for k, v in strategy_params.items()]
        ])

        # Interpret RSI based on current regime
        if df['rsi'].iloc[-1] > strategy_params.get('rsi_upper', 70):
            rsi_interpretation = signal_interpretations.get('rsi_overbought', 'Overbought')
        elif df['rsi'].iloc[-1] < strategy_params.get('rsi_lower', 30):
            rsi_interpretation = signal_interpretations.get('rsi_oversold', 'Oversold')
        else:
            rsi_interpretation = "Neutral"

        # === Combine all ML signals into a unified dataframe for backtesting ===
        # Create a main dataframe with all ML signals
        df_backtest = df.copy()

        # Add pattern predictions
        try:
            if 'results' in ml_pattern_report and not ml_pattern_report['results'].empty:
                pattern_results = ml_pattern_report['results'].copy()
                for col in ['prediction', 'probability']:
                    if col in pattern_results.columns:
                        df_backtest[f'pattern_{col}'] = pattern_results[col]
        except Exception as e:
            print(f"Error adding pattern predictions: {e}")

        # Add cluster assignments and anomaly scores
        try:
            if 'results' in ml_clusters_report and not ml_clusters_report['results'].empty:
                cluster_results = ml_clusters_report['results'].copy()
                for col in ['cluster', 'anomaly_score']:
                    if col in cluster_results.columns:
                        df_backtest[f'cluster_{col}'] = cluster_results[col]
        except Exception as e:
            print(f"Error adding cluster results: {e}")

        # Add anomaly detection scores
        try:
            if 'results' in ml_anomaly_report and not ml_anomaly_report['results'].empty:
                anomaly_results = ml_anomaly_report['results'].copy()
                for col in ['anomaly_score', 'is_anomaly']:
                    if col in anomaly_results.columns:
                        df_backtest[f'anomaly_{col}'] = anomaly_results[col]
        except Exception as e:
            print(f"Error adding anomaly results: {e}")

        # Add regime information
        try:
            if 'df_regimes' in regime_report:
                regime_results = regime_report['df_regimes'].copy()
                if 'regime' in regime_results.columns and 'regime' not in df_backtest.columns:
                    df_backtest['regime'] = regime_results['regime']
        except Exception as e:
            print(f"Error adding regime information: {e}")

        print(f"Backtest dataframe columns: {df_backtest.columns.tolist()}")

        # --- Correlation Analysis ---
        # Initialize CorrelationAnalysis with multiple correlation and feature selection methods
        correlation_methods = ['pearson', 'spearman', 'kendall']
        feature_selection_methods = ['mutual_info', 'random_forest', 'lasso']
        
        # Create the correlation analysis model with multiple methods
        correlation_model = CorrelationAnalysis(
            correlation_method=correlation_methods,
            feature_selection_method=feature_selection_methods
        )
        
        try:
            # Remove duplicate columns before correlation analysis
            df_correlation = df_backtest.copy()
            df_correlation = df_correlation.loc[:, ~df_correlation.columns.duplicated()]
            
            # Ensure 'returns' exists
            if 'returns' not in df_correlation.columns:
                if 'close' in df_correlation.columns:
                    df_correlation['returns'] = df_correlation['close'].pct_change().fillna(0)
                else:
                    raise KeyError("Target column 'returns' not found and cannot compute returns: 'close' column missing")
            
            # Use the same feature_cols as for ML
            corr_feature_cols = ['open', 'high', 'low', 'close', 'volume', 'ma_5', 'ma_9', 'ma_20', 'ma_50', 'ma_100', 
                                 'ma_200', 'bb_middle', 'bb_upper', 'bb_lower', 'macd_line', 'macd_signal', 'macd_hist', 
                                 'rsi', 'stoch_k', 'stoch_d', '+di', '-di', 'adx', 'cci', 'roc', 'momentum', 'cmf', 
                                 'mfi', 'tsi', 'tsi_signal', 'kst', 'kst_signal', 'sar', 'trend', 'cd_signal', 
                                 'arms_index', 'bulls_bears_ratio', 'buy_signal', 'sell_signal', 'target', 'regime', 
                                 'cluster_cluster', 'cluster_anomaly_score']
            
            # Make sure we only include columns that actually exist
            existing_cols = [col for col in corr_feature_cols if col in df_correlation.columns]
            
            # Run multi-method correlation analysis
            multi_method_results = correlation_model.run_multi_method_analysis(
                df_correlation, 
                existing_cols, 
                target_col='returns',
                threshold=0.8,
                n_select=5,
                classification=False
            )
            
            # Generate comparison results
            feature_importance_comparison = correlation_model.compare_method_combinations(
                key_metric='feature_importance'
            )
            
            unique_indicators_comparison = correlation_model.compare_method_combinations(
                key_metric='unique_indicators'
            )
            
            # Generate comparison visualizations
            feature_importance_comparison_fig = correlation_model.plot_method_comparison(
                key_metric='feature_importance',
                top_n=10
            )
            
            redundancy_groups_comparison_fig = correlation_model.plot_method_comparison(
                key_metric='redundancy_groups'
            )
            
            # Generate the single-method correlation report for backward compatibility
            # Set display_dashboard=False to avoid automatic display in the notebook
            correlation_report = correlation_model.generate_correlation_report(
                df_correlation, 
                existing_cols, 
                target_col='returns',
                display_dashboard=False,
                save_dashboard=True,
                dashboard_filename=f'correlation_dashboard_{symbol}.html',
                symbol=symbol,
                period=period,
                interval=interval
            )
            
            # Create visualizations using the utility functions
            correlation_figures = create_correlation_report_charts(correlation_report)
            
            # Add the multi-method comparison figures
            correlation_figures['feature_importance_comparison'] = feature_importance_comparison_fig
            correlation_figures['redundancy_groups_comparison'] = redundancy_groups_comparison_fig
            
            # Add correlation summary to the perfect storm analysis
            # Create a summary of the multi-method results
            multi_method_summary = html.Div([
                html.H4("Multi-Method Correlation Analysis Results"),
                html.P("The following results show the comparison of different correlation and feature selection methods:"),
                
                html.H5("Feature Importance Comparison"),
                html.P("This comparison shows how different feature importance scores vary across methods:"),
                html.Div(dcc.Graph(figure=feature_importance_comparison_fig, style={'height': '500px'})),
                
                html.H5("Redundancy Groups Comparison"),
                html.P("This comparison shows how redundancy detection varies across correlation methods:"),
                html.Div(dcc.Graph(figure=redundancy_groups_comparison_fig, style={'height': '500px'})),
                
                html.H5("Best Method Combination Recommendation"),
                html.P("Based on analysis results, the recommended correlation and feature selection methods are:"),
                # Determine best method combination based on feature importance and redundancy analysis
                html.Ul([
                    html.Li(f"For feature selection: {correlation_model.feature_selection_method}"),
                    html.Li(f"For correlation analysis: {correlation_model.correlation_method}"),
                ])
            ])
            
            # Create standard correlation dashboard component
            correlation_summary = create_correlation_dashboard_component(correlation_report)
            
            # Combine standard and multi-method summaries
            correlation_summary = html.Div([
                correlation_summary,
                multi_method_summary
            ])
            
        except Exception as e:
            print("Correlation analysis error:", e)
            traceback.print_exc()
            correlation_report = {
                'visualizations': {
                    'correlation_matrix': go.Figure().update_layout(title="Correlation Matrix Failed"),
                    'redundancy_groups': go.Figure().update_layout(title="Redundancy Groups Failed"),
                    'feature_importance': go.Figure().update_layout(title="Feature Importance Failed")
                }
            }
            correlation_figures = correlation_report['visualizations']
            correlation_summary = html.Div(["Correlation analysis failed: " + str(e)])

        # Create trading signals based on combined ML signals
        try:
            # Instead of immediately setting buy/sell signals, we'll first track individual indicator signals
            # and then apply a consensus filter
            df_backtest['individual_buy_signals'] = 0  # Count of indicators suggesting buy
            df_backtest['individual_sell_signals'] = 0  # Count of indicators suggesting sell
            df_backtest['active_indicators'] = 0  # Count of indicators that are active/available
            
            # Initialize buy/sell signal columns that will be used after consensus calculation
            df_backtest['buy_signal'] = 0
            df_backtest['sell_signal'] = 0
            
            # Dictionary to track which indicators are available in the dataframe
            available_indicators = {}

            # Make sure we have the necessary columns, otherwise create fallbacks
            if 'pattern_probability' not in df_backtest.columns:
                df_backtest['pattern_probability'] = df_backtest['rsi'] / 100  # Use RSI as a fallback
            
            if 'regime_name' not in df_backtest.columns:
                df_backtest['regime_name'] = ''  # Empty string as fallback
                
            if 'anomaly_is_anomaly' not in df_backtest.columns:
                df_backtest['anomaly_is_anomaly'] = 0  # No anomalies as fallback
            
            # =========== TRACKING INDIVIDUAL INDICATOR SIGNALS ===========
            # For each indicator, we'll track both if it's available and its signal
            
            # 1. RSI signals
            if 'rsi' in df_backtest.columns:
                available_indicators['rsi'] = True
                df_backtest['active_indicators'] += 1
                
                # Original threshold (RSI < 30)
                rsi_buy = df_backtest['rsi'] < 30
                df_backtest.loc[rsi_buy, 'individual_buy_signals'] += 1
                
                # Original threshold (RSI > 70)
                rsi_sell = df_backtest['rsi'] > 70
                df_backtest.loc[rsi_sell, 'individual_sell_signals'] += 1
                
                # New threshold (RSI crosses above 65)
                rsi_buy_new = (df_backtest['rsi'] > 65) & \
                             (df_backtest['rsi'].shift(1) <= 65)
                df_backtest.loc[rsi_buy_new, 'individual_buy_signals'] += 1
                
                # New threshold (RSI crosses below 40)
                rsi_sell_new = (df_backtest['rsi'] < 40) & \
                              (df_backtest['rsi'].shift(1) >= 40)
                df_backtest.loc[rsi_sell_new, 'individual_sell_signals'] += 1
            
            # 2. MA Crossover signals (Price vs 20-day MA)
            if all(col in df_backtest.columns for col in ['close', 'ma_20']):
                available_indicators['ma_20_price_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy when price crosses above 20-day MA
                ma_crossover = (df_backtest['close'] > df_backtest['ma_20']) & \
                            (df_backtest['close'].shift(1) <= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma_crossover, 'individual_buy_signals'] += 1
                
                # Sell when price crosses below 20-day MA
                ma_crossunder = (df_backtest['close'] < df_backtest['ma_20']) & \
                               (df_backtest['close'].shift(1) >= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma_crossunder, 'individual_sell_signals'] += 1
            
            # 3. ML-based signals
            if 'pattern_probability' in df_backtest.columns and df_backtest['pattern_probability'].notna().any():
                available_indicators['pattern_probability'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy on high probability of uptrend
                pattern_buy = df_backtest['pattern_probability'] > 0.95
                df_backtest.loc[pattern_buy, 'individual_buy_signals'] += 1
            
            if 'anomaly_is_anomaly' in df_backtest.columns and df_backtest['anomaly_is_anomaly'].sum() > 0:
                available_indicators['anomaly'] = True
                df_backtest['active_indicators'] += 1
                
                # Sell on anomaly detection
                anomaly_sell = df_backtest['anomaly_is_anomaly'] == 1
                df_backtest.loc[anomaly_sell, 'individual_sell_signals'] += 1
            
            # 4. Parabolic SAR signals
            if 'sar' in df_backtest.columns:
                available_indicators['sar'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: Price crosses above the Parabolic SAR
                sar_buy = (df_backtest['close'] > df_backtest['sar']) & \
                          (df_backtest['close'].shift(1) <= df_backtest['sar'].shift(1))
                df_backtest.loc[sar_buy, 'individual_buy_signals'] += 1
                
                # Sell: Price crosses below the Parabolic SAR
                sar_sell = (df_backtest['close'] < df_backtest['sar']) & \
                           (df_backtest['close'].shift(1) >= df_backtest['sar'].shift(1))
                df_backtest.loc[sar_sell, 'individual_sell_signals'] += 1
            
            # 5. 10-day Momentum signals
            if 'momentum' in df_backtest.columns:
                available_indicators['momentum'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: Momentum crosses above zero
                momentum_buy = (df_backtest['momentum'] > 0) & \
                              (df_backtest['momentum'].shift(1) <= 0)
                df_backtest.loc[momentum_buy, 'individual_buy_signals'] += 1
                
                # Sell: Momentum crosses below zero
                momentum_sell = (df_backtest['momentum'] < 0) & \
                               (df_backtest['momentum'].shift(1) >= 0)
                df_backtest.loc[momentum_sell, 'individual_sell_signals'] += 1
            
            # 6. KST signals
            if 'kst' in df_backtest.columns and 'kst_signal' in df_backtest.columns:
                available_indicators['kst'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: KST crosses above the KST Signal line
                kst_buy = (df_backtest['kst'] > df_backtest['kst_signal']) & \
                         (df_backtest['kst'].shift(1) <= df_backtest['kst_signal'].shift(1))
                df_backtest.loc[kst_buy, 'individual_buy_signals'] += 1
                
                # Sell: KST crosses below the KST Signal line
                kst_sell = (df_backtest['kst'] < df_backtest['kst_signal']) & \
                          (df_backtest['kst'].shift(1) >= df_backtest['kst_signal'].shift(1))
                df_backtest.loc[kst_sell, 'individual_sell_signals'] += 1
            
            # 7. ROC 12 signals
            if 'roc' in df_backtest.columns:
                available_indicators['roc'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: ROC crosses above zero
                roc_buy = (df_backtest['roc'] > 0) & \
                         (df_backtest['roc'].shift(1) <= 0)
                df_backtest.loc[roc_buy, 'individual_buy_signals'] += 1
                
                # Sell: ROC crosses below zero
                roc_sell = (df_backtest['roc'] < 0) & \
                          (df_backtest['roc'].shift(1) >= 0)
                df_backtest.loc[roc_sell, 'individual_sell_signals'] += 1
            
            # 8. Stochastic %K and %D signals
            if 'stoch_k' in df_backtest.columns and 'stoch_d' in df_backtest.columns:
                available_indicators['stoch'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: %K crosses above %D
                stoch_k_buy = (df_backtest['stoch_k'] > df_backtest['stoch_d']) & \
                             (df_backtest['stoch_k'].shift(1) <= df_backtest['stoch_d'].shift(1))
                df_backtest.loc[stoch_k_buy, 'individual_buy_signals'] += 1
                
                # Sell: %K crosses below %D
                stoch_k_sell = (df_backtest['stoch_k'] < df_backtest['stoch_d']) & \
                              (df_backtest['stoch_k'].shift(1) >= df_backtest['stoch_d'].shift(1))
                df_backtest.loc[stoch_k_sell, 'individual_sell_signals'] += 1
                
                # Buy: %D crosses below 20
                stoch_d_buy = (df_backtest['stoch_d'] < 20) & \
                             (df_backtest['stoch_d'].shift(1) >= 20)
                df_backtest.loc[stoch_d_buy, 'individual_buy_signals'] += 1
                
                # Sell: %D crosses above 80
                stoch_d_sell = (df_backtest['stoch_d'] > 80) & \
                              (df_backtest['stoch_d'].shift(1) <= 80)
                df_backtest.loc[stoch_d_sell, 'individual_sell_signals'] += 1
            
            # 9. TSI signals
            if 'tsi' in df_backtest.columns:
                available_indicators['tsi'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: TSI crosses above zero
                tsi_buy = (df_backtest['tsi'] > 0) & \
                         (df_backtest['tsi'].shift(1) <= 0)
                df_backtest.loc[tsi_buy, 'individual_buy_signals'] += 1
                
                # Sell: TSI crosses below zero
                tsi_sell = (df_backtest['tsi'] < 0) & \
                          (df_backtest['tsi'].shift(1) >= 0)
                df_backtest.loc[tsi_sell, 'individual_sell_signals'] += 1
            
            # 10. Moving Average price cross signals (5-day SMA)
            if 'ma_5' in df_backtest.columns:
                available_indicators['ma_5_price_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: Price crosses above 5-day SMA
                ma5_buy = (df_backtest['close'] > df_backtest['ma_5']) & \
                         (df_backtest['close'].shift(1) <= df_backtest['ma_5'].shift(1))
                df_backtest.loc[ma5_buy, 'individual_buy_signals'] += 1
                
                # Sell: Price crosses below 5-day SMA
                ma5_sell = (df_backtest['close'] < df_backtest['ma_5']) & \
                          (df_backtest['close'].shift(1) >= df_backtest['ma_5'].shift(1))
                df_backtest.loc[ma5_sell, 'individual_sell_signals'] += 1
            
            # 11. Moving Average price cross signals (9-day SMA)
            if 'ma_9' in df_backtest.columns:
                available_indicators['ma_9_price_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: Price crosses above 9-day SMA
                ma9_buy = (df_backtest['close'] > df_backtest['ma_9']) & \
                         (df_backtest['close'].shift(1) <= df_backtest['ma_9'].shift(1))
                df_backtest.loc[ma9_buy, 'individual_buy_signals'] += 1
                
                # Sell: Price crosses below 9-day SMA
                ma9_sell = (df_backtest['close'] < df_backtest['ma_9']) & \
                          (df_backtest['close'].shift(1) >= df_backtest['ma_9'].shift(1))
                df_backtest.loc[ma9_sell, 'individual_sell_signals'] += 1
            
            # 12. MA Crossovers: 5/20 SMA
            if 'ma_5' in df_backtest.columns and 'ma_20' in df_backtest.columns:
                available_indicators['ma_5_20_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: 5-day SMA crosses above 20-day SMA
                ma5_20_buy = (df_backtest['ma_5'] > df_backtest['ma_20']) & \
                            (df_backtest['ma_5'].shift(1) <= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma5_20_buy, 'individual_buy_signals'] += 1
                
                # Sell: 5-day SMA crosses below 20-day SMA
                ma5_20_sell = (df_backtest['ma_5'] < df_backtest['ma_20']) & \
                             (df_backtest['ma_5'].shift(1) >= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma5_20_sell, 'individual_sell_signals'] += 1
            
            # 13. MA Crossovers: 9/20 SMA
            if 'ma_9' in df_backtest.columns and 'ma_20' in df_backtest.columns:
                available_indicators['ma_9_20_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: 9-day SMA crosses above 20-day SMA
                ma9_20_buy = (df_backtest['ma_9'] > df_backtest['ma_20']) & \
                            (df_backtest['ma_9'].shift(1) <= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma9_20_buy, 'individual_buy_signals'] += 1
                
                # Sell: 9-day SMA crosses below 20-day SMA
                ma9_20_sell = (df_backtest['ma_9'] < df_backtest['ma_20']) & \
                             (df_backtest['ma_9'].shift(1) >= df_backtest['ma_20'].shift(1))
                df_backtest.loc[ma9_20_sell, 'individual_sell_signals'] += 1
            
            # 14. MA Crossovers: 20/50 SMA
            if 'ma_20' in df_backtest.columns and 'ma_50' in df_backtest.columns:
                available_indicators['ma_20_50_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: 20-day SMA crosses above 50-day SMA
                ma20_50_buy = (df_backtest['ma_20'] > df_backtest['ma_50']) & \
                             (df_backtest['ma_20'].shift(1) <= df_backtest['ma_50'].shift(1))
                df_backtest.loc[ma20_50_buy, 'individual_buy_signals'] += 1
                
                # Sell: 20-day SMA crosses below 50-day SMA
                ma20_50_sell = (df_backtest['ma_20'] < df_backtest['ma_50']) & \
                              (df_backtest['ma_20'].shift(1) >= df_backtest['ma_50'].shift(1))
                df_backtest.loc[ma20_50_sell, 'individual_sell_signals'] += 1
                
            # 15. MA Crossovers: 50/100 SMA
            if 'ma_50' in df_backtest.columns and 'ma_100' in df_backtest.columns:
                available_indicators['ma_50_100_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: 50-day SMA crosses above 100-day SMA
                ma50_100_buy = (df_backtest['ma_50'] > df_backtest['ma_100']) & \
                              (df_backtest['ma_50'].shift(1) <= df_backtest['ma_100'].shift(1))
                df_backtest.loc[ma50_100_buy, 'individual_buy_signals'] += 1
                
                # Sell: 50-day SMA crosses below 100-day SMA
                ma50_100_sell = (df_backtest['ma_50'] < df_backtest['ma_100']) & \
                               (df_backtest['ma_50'].shift(1) >= df_backtest['ma_100'].shift(1))
                df_backtest.loc[ma50_100_sell, 'individual_sell_signals'] += 1
                
            # 16. MA Crossovers: 100/200 SMA
            if 'ma_100' in df_backtest.columns and 'ma_200' in df_backtest.columns:
                available_indicators['ma_100_200_cross'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: 100-day SMA crosses above 200-day SMA
                ma100_200_buy = (df_backtest['ma_100'] > df_backtest['ma_200']) & \
                               (df_backtest['ma_100'].shift(1) <= df_backtest['ma_200'].shift(1))
                df_backtest.loc[ma100_200_buy, 'individual_buy_signals'] += 1
                
                # Sell: 100-day SMA crosses below 200-day SMA
                ma100_200_sell = (df_backtest['ma_100'] < df_backtest['ma_200']) & \
                                (df_backtest['ma_100'].shift(1) >= df_backtest['ma_200'].shift(1))
                df_backtest.loc[ma100_200_sell, 'individual_sell_signals'] += 1
            
            # 17. ADL (Accumulation/Distribution Line)
            # We need to calculate this first if it doesn't exist
            if 'adl' not in df_backtest.columns and all(col in df_backtest.columns for col in ['high', 'low', 'close', 'volume']):
                # Calculate Money Flow Multiplier
                mfm = ((df_backtest['close'] - df_backtest['low']) - (df_backtest['high'] - df_backtest['close'])) / (df_backtest['high'] - df_backtest['low'])
                # Replace inf and NaN values
                mfm = mfm.replace([np.inf, -np.inf], np.nan).fillna(0)
                # Calculate Money Flow Volume
                mfv = mfm * df_backtest['volume']
                # Calculate ADL
                df_backtest['adl'] = mfv.cumsum()
            
            if 'adl' in df_backtest.columns:
                available_indicators['adl'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: ADL is rising (current value > previous value)
                adl_buy = df_backtest['adl'] > df_backtest['adl'].shift(1)
                df_backtest.loc[adl_buy, 'individual_buy_signals'] += 1
                
                # Sell: ADL is falling (current value < previous value)
                adl_sell = df_backtest['adl'] < df_backtest['adl'].shift(1)
                df_backtest.loc[adl_sell, 'individual_sell_signals'] += 1
            
            # 18. Money Flow Index (MFI)
            if 'mfi' in df_backtest.columns:
                available_indicators['mfi'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: MFI crosses below 20
                mfi_buy = (df_backtest['mfi'] < 20) & \
                         (df_backtest['mfi'].shift(1) >= 20)
                df_backtest.loc[mfi_buy, 'individual_buy_signals'] += 1
                
                # Sell: MFI crosses above 80
                mfi_sell = (df_backtest['mfi'] > 80) & \
                          (df_backtest['mfi'].shift(1) <= 80)
                df_backtest.loc[mfi_sell, 'individual_sell_signals'] += 1
            
            # 19. ADX with +DI and -DI signals
            if all(col in df_backtest.columns for col in ['adx', '+di', '-di']):
                available_indicators['adx_di'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: ADX above 20 and +DI crosses above -DI
                adx_buy = (df_backtest['adx'] > 20) & \
                         (df_backtest['+di'] > df_backtest['-di']) & \
                         (df_backtest['+di'].shift(1) <= df_backtest['-di'].shift(1))
                df_backtest.loc[adx_buy, 'individual_buy_signals'] += 1
                
                # Sell: ADX above 20 and +DI crosses below -DI
                adx_sell = (df_backtest['adx'] > 20) & \
                          (df_backtest['+di'] < df_backtest['-di']) & \
                          (df_backtest['+di'].shift(1) >= df_backtest['-di'].shift(1))
                df_backtest.loc[adx_sell, 'individual_sell_signals'] += 1
            
            # 20. MACD signals
            if all(col in df_backtest.columns for col in ['macd_line', 'macd_signal']):
                available_indicators['macd'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: MACD crosses above Signal line
                macd_buy = (df_backtest['macd_line'] > df_backtest['macd_signal']) & \
                          (df_backtest['macd_line'].shift(1) <= df_backtest['macd_signal'].shift(1))
                df_backtest.loc[macd_buy, 'individual_buy_signals'] += 1
                
                # Sell: MACD crosses below Signal line
                macd_sell = (df_backtest['macd_line'] < df_backtest['macd_signal']) & \
                           (df_backtest['macd_line'].shift(1) >= df_backtest['macd_signal'].shift(1))
                df_backtest.loc[macd_sell, 'individual_sell_signals'] += 1
            
            # 21. Bollinger Bands C/D Trigger (Trend change)
            if 'trend' in df_backtest.columns:
                available_indicators['bb_trend'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: Trend changes from down to up
                bb_buy = (df_backtest['trend'] > 0) & \
                        (df_backtest['trend'].shift(1) <= 0)
                df_backtest.loc[bb_buy, 'individual_buy_signals'] += 1
                
                # Sell: Trend changes from up to down
                bb_sell = (df_backtest['trend'] < 0) & \
                         (df_backtest['trend'].shift(1) >= 0)
                df_backtest.loc[bb_sell, 'individual_sell_signals'] += 1
            
            # 22. Chaikin Money Flow (CMF)
            if 'cmf' in df_backtest.columns:
                available_indicators['cmf'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: CMF crosses above zero
                cmf_buy = (df_backtest['cmf'] > 0) & \
                         (df_backtest['cmf'].shift(1) <= 0)
                df_backtest.loc[cmf_buy, 'individual_buy_signals'] += 1
                
                # Sell: CMF crosses below zero
                cmf_sell = (df_backtest['cmf'] < 0) & \
                          (df_backtest['cmf'].shift(1) >= 0)
                df_backtest.loc[cmf_sell, 'individual_sell_signals'] += 1
            
            # 23. Commodity Channel Index (CCI)
            if 'cci' in df_backtest.columns:
                available_indicators['cci'] = True
                df_backtest['active_indicators'] += 1
                
                # Buy: CCI crosses above -100
                cci_buy = (df_backtest['cci'] > -100) & \
                         (df_backtest['cci'].shift(1) <= -100)
                df_backtest.loc[cci_buy, 'individual_buy_signals'] += 1
                
                # Sell: CCI crosses below 100
                cci_sell = (df_backtest['cci'] < 100) & \
                          (df_backtest['cci'].shift(1) >= 100)
                df_backtest.loc[cci_sell, 'individual_sell_signals'] += 1
            
            # =========== APPLYING CONSENSUS FILTER ===========
            # Now we'll set buy/sell signals only when ALL active indicators agree
            
            # Count how many indicators are available
            num_active_indicators = len(available_indicators)
            print(f"Number of active indicators: {num_active_indicators}")
            print(f"Available indicators: {list(available_indicators.keys())}")
            
            # Create a minimum threshold based on available indicators
            # Option 1: Require ALL indicators to agree
            full_consensus_threshold = df_backtest['active_indicators']
            
            # Option 2: Require a strong consensus (>75%) of indicators to agree
            strong_consensus_threshold = df_backtest['active_indicators'] * 0.75
            
            # Option 3: Require a majority (>50%) of indicators to agree
            majority_threshold = df_backtest['active_indicators'] * 0.5
            
            # Option 4: Require a minority (>25%) of indicators to agree
            minority_threshold = df_backtest['active_indicators'] * 0.25
            
            # Apply full consensus rule - only generate signal when ALL indicators agree
            # Set a signal when the number of individual signals equals the number of active indicators
            df_backtest.loc[df_backtest['individual_buy_signals'] == full_consensus_threshold, 'buy_signal'] = 1
            df_backtest.loc[df_backtest['individual_sell_signals'] == full_consensus_threshold, 'sell_signal'] = 1
            
            print(f"Full consensus signals: {df_backtest['buy_signal'].sum()} buys, {df_backtest['sell_signal'].sum()} sells")
            
            # If we have very few signals with full consensus, fall back to strong consensus
            if df_backtest['buy_signal'].sum() < 2 or df_backtest['sell_signal'].sum() < 2:
                print("Full consensus produced too few signals, falling back to strong consensus (>75%)")
                df_backtest['buy_signal'] = 0
                df_backtest['sell_signal'] = 0
                
                # Apply strong consensus rule (>75% of indicators agree)
                df_backtest.loc[df_backtest['individual_buy_signals'] >= strong_consensus_threshold, 'buy_signal'] = 1
                df_backtest.loc[df_backtest['individual_sell_signals'] >= strong_consensus_threshold, 'sell_signal'] = 1
                
                print(f"Strong consensus signals: {df_backtest['buy_signal'].sum()} buys, {df_backtest['sell_signal'].sum()} sells")
            
            # If still too few signals, fall back to majority rule
            if df_backtest['buy_signal'].sum() < 2 or df_backtest['sell_signal'].sum() < 2:
                print("Strong consensus produced too few signals, falling back to majority rule (>50%)")
                df_backtest['buy_signal'] = 0
                df_backtest['sell_signal'] = 0
                
                # Apply majority rule (>50% of indicators agree)
                df_backtest.loc[df_backtest['individual_buy_signals'] >= majority_threshold, 'buy_signal'] = 1
                df_backtest.loc[df_backtest['individual_sell_signals'] >= majority_threshold, 'sell_signal'] = 1
                
                print(f"Majority rule signals: {df_backtest['buy_signal'].sum()} buys, {df_backtest['sell_signal'].sum()} sells")
            
            # If still too few signals, fall back to minority rule
            if df_backtest['buy_signal'].sum() < 2 or df_backtest['sell_signal'].sum() < 2:
                print("Majority rule produced too few signals, falling back to minority rule (>25%)")
                df_backtest['buy_signal'] = 0
                df_backtest['sell_signal'] = 0
                
                # Apply minority rule (>25% of indicators agree)
                df_backtest.loc[df_backtest['individual_buy_signals'] >= minority_threshold, 'buy_signal'] = 1
                df_backtest.loc[df_backtest['individual_sell_signals'] >= minority_threshold, 'sell_signal'] = 1
                
                print(f"Minority rule signals: {df_backtest['buy_signal'].sum()} buys, {df_backtest['sell_signal'].sum()} sells")
            
            # Make sure we have at least some buy and sell signals for testing
            if df_backtest['buy_signal'].sum() == 0:
                print("WARNING: No buy signals were generated using consensus approaches")
                # Add a single buy signal for testing in the middle of the dataset
                middle_idx = len(df_backtest) // 2
                df_backtest.iloc[middle_idx, df_backtest.columns.get_loc('buy_signal')] = 1
                
            if df_backtest['sell_signal'].sum() == 0:
                print("WARNING: No sell signals were generated using consensus approaches")
                # Add a sell signal after the first buy signal
                buy_indices = np.where(df_backtest['buy_signal'] == 1)[0]
                if len(buy_indices) > 0:
                    sell_idx = min(buy_indices[0] + 10, len(df_backtest) - 1)
                    df_backtest.iloc[sell_idx, df_backtest.columns.get_loc('sell_signal')] = 1
                else:
                    # If still no buy signals, add a sell signal near the end
                    sell_idx = int(len(df_backtest) * 0.75)
                    df_backtest.iloc[sell_idx, df_backtest.columns.get_loc('sell_signal')] = 1
                    
            # Print summary of signals to help with debugging
            print(f"Generated {df_backtest['buy_signal'].sum()} buy signals and {df_backtest['sell_signal'].sum()} sell signals using consensus approach")
            
        except Exception as e:
            print(f"Error creating trading signals: {e}")
            traceback.print_exc()
            # Create simple default signals
            df_backtest['buy_signal'] = 0
            df_backtest['sell_signal'] = 0
            # Add a few signals to ensure we have something to test
            quarter = len(df_backtest) // 4
            df_backtest.iloc[quarter, df_backtest.columns.get_loc('buy_signal')] = 1
            df_backtest.iloc[quarter*2, df_backtest.columns.get_loc('sell_signal')] = 1
            df_backtest.iloc[quarter*3, df_backtest.columns.get_loc('buy_signal')] = 1

        # Initialize the backtester with appropriate parameters
        backtester = BacktestingEngine(
            initial_capital=100000,  # Starting with $100,000
            commission=0.001,        # 0.1% commission per trade
            risk_free_rate=0.02,     # 2% annual risk-free rate
            slippage_model='fixed',  # Fixed slippage model
            slippage_value=0.0005,   # 0.05% slippage
            position_sizing='fixed',  # Fixed position sizing
            max_position_size=0.2    # Use 20% of portfolio per position
        )
        
        try:
            # Make sure dataframe is sorted by date
            df_backtest = df_backtest.sort_index()
            
            # Make sure all necessary columns exist
            required_cols = ['open', 'high', 'low', 'close', 'volume', 'buy_signal', 'sell_signal']
            for col in required_cols:
                if col not in df_backtest.columns:
                    print(f"Missing required column {col}! Creating fallback.")
                    if col in ['buy_signal', 'sell_signal']:
                        df_backtest[col] = 0
                    elif col == 'volume':
                        df_backtest[col] = 1000000  # Default volume
                    else:
                        # For price columns, use close if available
                        df_backtest[col] = df_backtest.get('close', 100)
            
            # Fill any NA values
            df_backtest = df_backtest.fillna(method='ffill').fillna(method='bfill')
            
            # Run the backtest with the prepared dataframe
            backtester.run_backtest(df_backtest)
            
            # Get the performance metrics
            performance_metrics = backtester.metrics
            
            # Create enhanced backtesting chart
            backtesting_chart = go.Figure()
            
            # Create subplot with 2 rows for price and portfolio value
            backtesting_chart = make_subplots(
                rows=2, 
                cols=1, 
                shared_xaxes=True, 
                vertical_spacing=0.1, 
                row_heights=[0.6, 0.4],
                subplot_titles=("Stock Price & Signals", "Portfolio Performance")
            )
            
            # Add stock price to top subplot
            backtesting_chart.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=backtester.results['close'],
                    mode='lines',
                    name="Stock Price",
                    line=dict(color='black', width=1)
                ),
                row=1, col=1
            )
            
            # Add buy signals
            if backtester.trades is not None and not backtester.trades.empty:
                buy_trades = backtester.trades[backtester.trades['type'] == 'buy']
                if not buy_trades.empty:
                    backtesting_chart.add_trace(
                        go.Scatter(
                            x=buy_trades['date'],
                            y=buy_trades['price'],
                            mode='markers',
                            name="Buy",
                            marker=dict(symbol='triangle-up', size=10, color='green')
                        ),
                        row=1, col=1
                    )
                
                # Add sell signals
                sell_trades = backtester.trades[backtester.trades['type'] == 'sell']
                if not sell_trades.empty:
                    backtesting_chart.add_trace(
                        go.Scatter(
                            x=sell_trades['date'],
                            y=sell_trades['price'],
                            mode='markers',
                            name="Sell",
                            marker=dict(symbol='triangle-down', size=10, color='red')
                        ),
                        row=1, col=1
                    )
            
            # Add portfolio value to bottom subplot
            backtesting_chart.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=backtester.results['portfolio_value'],
                    mode='lines',
                    name="Strategy",
                    line=dict(color='blue')
                ),
                row=2, col=1
            )
            
            # Add buy & hold performance
            # Calculate buy & hold performance
            initial_price = backtester.results['close'].iloc[0]
            initial_shares = backtester.initial_capital / initial_price
            buy_hold_values = backtester.results['close'] * initial_shares
            
            backtesting_chart.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=buy_hold_values,
                    mode='lines',
                    name="Buy & Hold",
                    line=dict(color='gray', dash='dash')
                ),
                row=2, col=1
            )
            
            # Add initial capital line to bottom subplot
            backtesting_chart.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=[backtester.initial_capital] * len(backtester.results),
                    mode='lines',
                    name="Initial Capital",
                    line=dict(color='red', dash='dot', width=1)
                ),
                row=2, col=1
            )
            
            # Format summary statistics to display on the chart
            if backtester.metrics is not None:
                # Calculate buy & hold performance metrics
                buy_hold_return = (buy_hold_values.iloc[-1] / backtester.initial_capital) - 1
                
                stats_text = (
                    f"Strategy Return: {backtester.metrics['total_return']:.2%}<br>"
                    f"Buy & Hold Return: {buy_hold_return:.2%}<br>"
                    f"Alpha: {backtester.metrics['total_return'] - buy_hold_return:.2%}<br>"
                    f"Sharpe Ratio: {backtester.metrics['sharpe_ratio']:.2f}<br>"
                    f"Max Drawdown: {backtester.metrics['max_drawdown']:.2%}<br>"
                    f"Win Rate: {backtester.metrics['win_rate']:.2%}<br>"
                    f"Total Trades: {backtester.metrics['total_trades']}"
                )
                
                backtesting_chart.add_annotation(
                    text=stats_text,
                    xref="paper", yref="paper",
                    x=0.01, y=0.99,
                    showarrow=False,
                    font=dict(size=10),
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1,
                    align="left"
                )
            
            # Update layout
            backtesting_chart.update_layout(
                height=700,
                title="Backtesting Results",
                xaxis_title="Date",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                margin=dict(l=50, r=50, t=80, b=50)
            )
            
            # Update axes titles
            backtesting_chart.update_yaxes(title_text="Price ($)", row=1, col=1)
            backtesting_chart.update_yaxes(title_text="Portfolio Value ($)", row=2, col=1)
            
            # Create a separate strategy comparison chart
            strategy_comparison = go.Figure()
            
            # Calculate percentage returns for both strategies
            strategy_pct_return = (backtester.results['portfolio_value'] / backtester.initial_capital) - 1
            buy_hold_pct_return = (buy_hold_values / backtester.initial_capital) - 1
            
            # Add strategy percentage return
            strategy_comparison.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=strategy_pct_return * 100,  # Convert to percentage
                    mode='lines',
                    name="Trading Strategy",
                    line=dict(color='blue', width=2)
                )
            )
            
            # Add buy & hold percentage return
            strategy_comparison.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=buy_hold_pct_return * 100,  # Convert to percentage
                    mode='lines',
                    name="Buy & Hold",
                    line=dict(color='gray', width=2, dash='dash')
                )
            )
            
            # Add zero line
            strategy_comparison.add_trace(
                go.Scatter(
                    x=backtester.results.index,
                    y=[0] * len(backtester.results),
                    mode='lines',
                    name="Break Even",
                    line=dict(color='red', dash='dot')
                )
            )
            
            # Calculate outperformance
            if backtester.metrics is not None:
                outperformance = backtester.metrics['total_return'] - buy_hold_return
                outperform_text = (
                    f"Strategy outperformed by {outperformance:.2%}" if outperformance > 0 else
                    f"Strategy underperformed by {-outperformance:.2%}"
                )
                
                strategy_comparison.add_annotation(
                    text=outperform_text,
                    xref="paper", yref="paper",
                    x=0.5, y=0.03,
                    showarrow=False,
                    font=dict(size=14, color='blue' if outperformance > 0 else 'red'),
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    borderwidth=1
                )
            
            # Update layout for strategy comparison
            strategy_comparison.update_layout(
                height=400,
                title="Strategy vs Buy & Hold Comparison",
                xaxis_title="Date",
                yaxis_title="Return (%)",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                margin=dict(l=50, r=50, t=80, b=50)
            )
            
            # Instead of trying to modify the app layout, let's just create the strategy comparison chart
            # We'll add it to the dashboard later if needed
            
        except Exception as e:
            print(f"Error running backtest: {e}")
            traceback.print_exc()
            # Create an empty figure if backtesting fails
            backtesting_chart = go.Figure()
            backtesting_chart.update_layout(
                title="Backtesting Failed: " + str(e),
                annotations=[{
                    'text': 'Error during backtesting. See console for details.',
                    'xref': 'paper',
                    'yref': 'paper',
                    'x': 0.5,
                    'y': 0.5,
                    'showarrow': False,
                    'font': {'size': 16}
                }]
            )
            performance_metrics = {}
        
        # Create Perfect Storm analysis and append adaptive thresholds info
        perfect_storm_analysis = create_perfect_storm_analysis(df)
        
        # Add backtesting results to the analysis
        if performance_metrics:
            backtest_html = html.Div([
                html.H4("Backtesting Performance Metrics"),
                html.P(f"Total Return: {performance_metrics.get('total_return', 'N/A'):.2%}"),
                html.P(f"Sharpe Ratio: {performance_metrics.get('sharpe_ratio', 'N/A'):.2f}"),
                html.P(f"Max Drawdown: {performance_metrics.get('max_drawdown', 'N/A'):.2%}"),
                html.P(f"Win Rate: {performance_metrics.get('win_rate', 'N/A'):.2%}"),
                html.P(f"Profit Factor: {performance_metrics.get('profit_factor', 'N/A'):.2f}"),
                html.P(f"Total Trades: {performance_metrics.get('total_trades', 'N/A')}"),
            ])
            
            # Unpack the original list into the new list of children
            perfect_storm_analysis_content = perfect_storm_analysis if isinstance(perfect_storm_analysis, list) else [perfect_storm_analysis]
            
            perfect_storm_analysis = html.Div(
                perfect_storm_analysis_content + [ # Use list concatenation
                    html.H4("Adaptive Thresholds"),
                    html.Pre(str(dynamic_thresholds)),
                    backtest_html,
                    correlation_summary
                ]
            )
        else:
            # Unpack the original list into the new list of children
            perfect_storm_analysis_content = perfect_storm_analysis if isinstance(perfect_storm_analysis, list) else [perfect_storm_analysis]
            
            perfect_storm_analysis = html.Div(
                 perfect_storm_analysis_content + [ # Use list concatenation
                    html.H4("Adaptive Thresholds"),
                    html.Pre(str(dynamic_thresholds)),
                    correlation_summary
                ]
            )

        return (market_data_info, main_chart, indicators_chart, moving_averages_chart,
                volume_chart, oscillators_chart, sentiment_chart, ml_pattern_report['visualizations']['predictions'], 
                ml_pattern_report['visualizations']['roc_curve'], 
                ml_pattern_report['visualizations']['precision_recall_curve'], 
                ml_pattern_report['visualizations']['confusion_matrix'],
                ml_clusters_report['visualizations']['cluster_scatter'],
                ml_clusters_report['visualizations']['cluster_tsne'],
                ml_clusters_report['visualizations']['cluster_umap'],
                ml_clusters_report['visualizations']['clusters_time_series'], 
                ml_clusters_report['visualizations']['anomaly_scores'], 
                ml_anomaly_report['visualizations']['anomaly_scores'], 
                ml_anomaly_report['visualizations']['price_anomalies'], 
                regime_report['visualizations']['regimes'], 
                regime_report['visualizations']['transition_matrix'], 
                regime_report['visualizations']['regime_statistics'], 
                regime_report['visualizations']['returns_distribution'], 
                backtesting_chart,
                correlation_figures['correlation_matrix'],
                correlation_figures['redundancy_groups'],
                correlation_figures['feature_importance'],
                perfect_storm_analysis)

    @app.callback(
        Output('alerts-div', 'children'),
        Input('real-time-alerts', 'n_intervals')
    )
    def update_alerts(n):
        alerts = []
        if random.random() > 0.8:
            alerts.append("ALERT: Significant market signal detected!")
        if not alerts:
            alerts.append("No alerts at this time.")
        return html.Ul([html.Li(alert) for alert in alerts])

    @app.callback(
        [Output('portfolio-report-status', 'children'),
         Output('portfolio-report-container', 'style'),
         Output('portfolio-report-summary', 'children'),
         Output('portfolio-efficient-frontier', 'figure'),
         Output('portfolio-allocation-pie', 'figure'),
         Output('portfolio-allocation-bar', 'figure'),
         Output('portfolio-risk-contribution', 'figure'),
         Output('portfolio-performance-metrics', 'figure')],
        [Input('generate-portfolio-button', 'n_clicks')],
        [State('portfolio-symbols-input', 'value'),
         State('portfolio-period-dropdown', 'value'),
         State('portfolio-capital-input', 'value'),
         State('portfolio-risk-profile-dropdown', 'value')],
        prevent_initial_call=True
    )
    def generate_portfolio_report(n_clicks, symbols_input, period, capital, risk_profile):
        if n_clicks is None or n_clicks == 0:
            raise PreventUpdate
            
        # Validate inputs
        if not symbols_input or not period or not capital:
            return (
                html.Div("Error: All fields must be filled out.", style={'color': 'red'}),
                {'display': 'none'},
                None, {}, {}, {}, {}, {}
            )
            
        # Parse symbols
        try:
            symbols = [s.strip().upper() for s in symbols_input.split(',')]
            if len(symbols) < 2:
                return (
                    html.Div("Error: Please enter at least two stock symbols separated by commas.", style={'color': 'red'}),
                    {'display': 'none'},
                    None, {}, {}, {}, {}, {}
                )
        except Exception as e:
            return (
                html.Div(f"Error parsing symbols: {str(e)}", style={'color': 'red'}),
                {'display': 'none'},
                None, {}, {}, {}, {}, {}
            )
            
        # Ensure capital is valid
        try:
            capital = float(capital)
            if capital <= 0:
                return (
                    html.Div("Error: Capital must be a positive number.", style={'color': 'red'}),
                    {'display': 'none'},
                    None, {}, {}, {}, {}, {}
                )
        except:
            return (
                html.Div("Error: Invalid capital amount.", style={'color': 'red'}),
                {'display': 'none'},
                None, {}, {}, {}, {}, {}
            )
        
        # Initialize market data retriever and portfolio optimizer
        data_retriever = MarketDataRetriever()
        portfolio_optimizer = PortfolioOptimizer()
        
        try:
            # Create a loading message while processing
            status_message = html.Div("Generating portfolio report... Please wait.", style={'color': 'blue'})
            
            # Initialize storage for price dataframes and returns dataframes
            price_dfs = {}
            all_returns = {}
            
            # Fetch historical data for each symbol
            for symbol in symbols:
                stock_data = data_retriever.get_stock_history(symbol, interval='1d', period=period)
                
                if stock_data is None or stock_data.empty:
                    return (
                        html.Div(f"Error: Could not retrieve data for {symbol}.", style={'color': 'red'}),
                        {'display': 'none'},
                        None, {}, {}, {}, {}, {}
                    )
                
                # Store the closing prices and calculate returns
                price_dfs[symbol] = stock_data['close']
                returns = stock_data['close'].pct_change().dropna()
                all_returns[symbol] = returns
            
            # Create combined price and returns dataframes
            price_df = pd.DataFrame(price_dfs)
            returns_df = pd.DataFrame(all_returns)
            
            # Drop rows with any NaN values (these tend to appear at the beginning since some stocks may have different trading days)
            returns_df = returns_df.dropna()
            
            # Check if we have enough data
            if len(returns_df) < 30:  # Arbitrary minimum length for meaningful analysis
                return (
                    html.Div("Error: Not enough historical data for meaningful portfolio optimization.", style={'color': 'red'}),
                    {'display': 'none'},
                    None, {}, {}, {}, {}, {}
                )
            
            # Generate the portfolio report
            portfolio_report = portfolio_optimizer.generate_portfolio_report(
                returns_df, 
                total_capital=capital, 
                risk_profile=risk_profile
            )
            
            # Store returns_df in the report for risk contribution calculations
            portfolio_report['returns_df'] = returns_df
            
            # Create Plotly visualizations using utility function
            portfolio_figures = create_portfolio_report_charts(portfolio_report, 
                                                             symbol=f"{len(symbols)}-Stock Portfolio")
            
            # Create HTML summary component
            summary_component = create_portfolio_report_component(portfolio_report, 
                                                                symbol=f"{len(symbols)}-Stock Portfolio")
            
            # Return the report components
            return (
                html.Div("Portfolio report generated successfully.", style={'color': 'green'}),
                {'display': 'block'},  # Show the report container
                summary_component,
                portfolio_figures['efficient_frontier'],
                portfolio_figures['portfolio_allocation_pie'],
                portfolio_figures['portfolio_allocation_bar'],
                portfolio_figures.get('risk_contribution', {}),  # This may not always be available
                portfolio_figures.get('portfolio_performance', {})  # This may not always be available
            )
            
        except Exception as e:
            print(f"Error generating portfolio report: {e}")
            traceback.print_exc()
            return (
                html.Div(f"Error: {str(e)}", style={'color': 'red'}),
                {'display': 'none'},
                None,
                go.Figure().update_layout(title="Error Generating Efficient Frontier"),
                go.Figure().update_layout(title="Error Generating Portfolio Allocation"),
                go.Figure().update_layout(title="Error Generating Portfolio Weights"),
                go.Figure().update_layout(title="Error Generating Risk Contribution"),
                go.Figure().update_layout(title="Error Generating Performance Metrics")
            )
